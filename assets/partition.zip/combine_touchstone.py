import os
import re
from collections import defaultdict
import skrf as rf

def generate_netlist_with_common_freq(sparam_files):
    port_map = {}
    port_count = defaultdict(int)
    freq_summary = {}

    port_pattern = re.compile(r"^! *Port\[\d+\] *= *(\S+)", re.IGNORECASE)

    # --- 讀取每個 S 參數檔 ---
    for file_path in sparam_files:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()

        ports = []
        for line in lines:
            m = port_pattern.match(line.strip())
            if m:
                pname = m.group(1)
                ports.append(pname)
                port_count[pname] += 1
        port_map[file_path] = ports

        # 讀取頻率範圍
        ntwk = rf.Network(file_path)
        fmin = ntwk.f.min()
        fmax = ntwk.f.max()
        freq_summary[os.path.basename(file_path)] = (fmin, fmax)

    # 求共同頻率區間
    fmins = [v[0] for v in freq_summary.values()]
    fmaxs = [v[1] for v in freq_summary.values()]
    common_min = max(fmins)
    common_max = min(fmaxs)

    # net 命名規則
    def net_name(pname):
        return f"net_{pname}" if port_count[pname] > 1 else pname

    # === 生成 Netlist ===
    lines = []
    lines.append("* ======================================================\n")
    lines.append("* Auto-generated Circuit Netlist with .MODEL and Common Frequency\n")
    lines.append("* ======================================================\n\n")
    lines.append(f"* Common Frequency Range: {common_min/1e9:.3f} - {common_max/1e9:.3f} GHz\n\n")

    lines.append(".option PARHIER='local'\n\n")

    # --- 建立 .model 區段 ---
    for file_path in sparam_files:
        model_name = os.path.splitext(os.path.basename(file_path))[0]
        fmin, fmax = freq_summary[os.path.basename(file_path)]
        lines.append(f".model {model_name} S TSTONEFILE=\"{file_path}\"\n"
                     f"+ INTERPOLATION=LINEAR INTDATTYP=MA HIGHPASS=10 LOWPASS=10\n"
                     f"+ convolution=0 enforce_passivity=0 Noisemodel=External\n")
    lines.append("\n")

    # --- 建立 S 元件 ---
    s_count = 1
    for file_path, ports in port_map.items():
        model_name = os.path.splitext(os.path.basename(file_path))[0]
        nets = [net_name(p) for p in ports]
        fmin, fmax = freq_summary[os.path.basename(file_path)]
        lines.append(f"* {model_name}: {fmin/1e9:.3f} - {fmax/1e9:.3f} GHz\n")
        lines.append(f"S{s_count} " + " ".join(nets) + f' FQMODEL="{model_name}"\n\n')
        s_count += 1

    # --- 外部 Port ---
    # lines.append("* External Ports\n")
    single_ports = [p for p, c in port_count.items() if c == 1]
    # for idx, pname in enumerate(single_ports, start=1):
    #     lines.append(f"R{pname} {pname} 0 PORTNUM={idx} RZ=50 IZ=0\n")
    #     lines.append(f".PORT {pname} 0 {idx} R{pname}\n")

    lines.append("\n.end\n")

    netlist_text = "".join(lines)

    return {
        "netlist": netlist_text,
        "single_ports": single_ports,
        "freq_summary": freq_summary,
        "common_freq_range": (common_min, common_max)
    }

s_files = [
    r"d:/demo/x.s3p",
    r"d:/demo/y.s3p"
]
data = generate_netlist_with_common_freq(s_files)
net_path = 'd:/demo/combine.net'
with open(net_path, 'w') as f:
    f.write(data['netlist'])

#%%
from pyaedt import Circuit
circuit = Circuit(version=2024.1)
circuit.add_netlist_datablock(net_path)
number = len(data['single_ports'])
for n, port in enumerate(data['single_ports']):
    circuit.modeler.schematic.create_interface_port(port, location=(0, 0.01*n))


setup = circuit.create_setup(setup_type=circuit.SETUPS.NexximLNA)
fmin, fmax = data['common_freq_range']
setup.props['SweepDefinition']['Data'] = f'LINC {fmin}Hz {fmax}Hz 2001'

circuit.analyze()
circuit.export_touchstone(output_file=f'd:/demo/comnbine.s{number}p')