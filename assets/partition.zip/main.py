from pyedb import Edb
import os, re
import datetime
import shutil
from split import split_path_by_line
from utils import centroid_cutline_sign
from collections import defaultdict

edb_version = '2024.1'
edb_path = r"D:/demo2/full.aedb"


timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
backup_dir = os.path.join(os.path.dirname(edb_path), f"{timestamp}")
os.makedirs(backup_dir, exist_ok=True)

aedb_name = os.path.basename(edb_path)
aedb_copy_path = os.path.join(backup_dir, aedb_name)
shutil.copytree(edb_path, aedb_copy_path)

edb = Edb(aedb_copy_path, version=edb_version)

label_cutting = {}
for p in edb.modeler.get_primitives(layer_name='Outline'):
    label_cutting[p.aedt_name] = p.center_line



#%%
ports = defaultdict(list)
def partition(trace, cut_line, new_net_name):
    result = split_path_by_line(trace.center_line, cut_line, trace.width)
    
    if result:
        pts1, pts2, swapped = result
    
        cloned_trace = trace.clone()
        for p in edb.modeler.primitives:
            if p.id == cloned_trace.GetId():
                break
        
        trace.center_line = pts1
        trace.net_name = new_net_name   
        
        p.center_line = pts2
        
        _, t1, t2 = trace.get_end_cap_style()
        if swapped:
            trace.set_end_cap_style(type(t1).Flat, t2)
            p.set_end_cap_style(t1, type(t1).Flat)
        else:   
            trace.set_end_cap_style(t1, type(t1).Flat)
            p.set_end_cap_style(type(t1).Flat, t2)
        
        cut_point = pts2[-1] if swapped else pts2[0]
        ports[trace.id].append((cut_point, 'out'))
        ports[p.id].append((cut_point, 'in'))
        
    else:
        pts = list(zip(*trace.points()))
        if centroid_cutline_sign(pts, cut_line) == 1:
            trace.net_name = new_net_name


def cutout(signal_nets, reference_nets, output_path):
    edb.cutout(signal_nets=all_nets, 
               reference_nets=reference_nets, 
               extent_type='Bounding',
               open_cutout_at_end = False,
               output_aedb_path=output_path,
               expansion_size=0.001)    



for label, cutting in label_cutting.items():   
    for net_name, net in edb.nets.signal_nets.items():
        if net_name.endswith('_'):
            continue
        
        new_net_name = f'{net_name}_{label}_'
        edb.nets.find_or_create_net(new_net_name)
       
        paths = [p for p in net.primitives if p.type == 'Path']
        polygons = [p for p in net.primitives if p.type == 'Polygon']
        padstacks = [p for p in edb.padstacks.padstack_instances.values() if p.net_name==net_name]
    
        for p in paths:
            partition(p, cutting, new_net_name)

        for p in polygons:
            pts = list(zip(*p.points()))
            if centroid_cutline_sign(pts, cutting) == 1:
                p.net_name = new_net_name
    
        for p in padstacks:
            pts = [p.position, p.position, p.position]
            if centroid_cutline_sign(pts, cutting) == 1:
                p.net_name = new_net_name
    
edb.save()
edb.close()

#%%
cutout_edb = {}

edb = Edb(aedb_copy_path, version=edb_version)
reference_nets = list(edb.nets.power_nets.keys()) 

for label, cutting in label_cutting.items():
    all_nets = [net_name for net_name in edb.nets.signal_nets if net_name.endswith(f'_{label}_')]
    
    cutout_path = aedb_copy_path.replace('.aedb', f'_{label}.aedb')
    cutout(all_nets, reference_nets, cutout_path)
    cutout_edb[int(label)] = cutout_path

label = int(label) + 1    
all_nets = [net_name for net_name in edb.nets.signal_nets if not net_name.endswith('_')]
cutout_path = aedb_copy_path.replace('.aedb', f'_{label}.aedb')
cutout(all_nets, reference_nets, cutout_path)

cutout_edb[label] = cutout_path

edb.close_edb()

#%%

for label, edb_path in cutout_edb.items():

    edb = Edb(edb_path, version=edb_version)
    
    for p in edb.modeler.primitives:
        if p.id not in ports:
            continue
        for item in ports[p.id]:
            location, io = item
            net_name = re.sub(r'_\d+_$', '', p.net_name)
            cut_number = label-1 if io == 'in' else label
            edb.hfss.create_edge_port_vertical(p.id, location, port_name=f'{net_name}_{cut_number}')

    edb.save()
    edb.close_edb()