text = '''
if not 'OSL_REGULAR_EXECUTION' in locals(): 
    OSL_REGULAR_EXECUTION = False


if not OSL_REGULAR_EXECUTION:
    x1 = 0.1
    x2 = 0.1

y = (x1 -1)**2 + (x2 -3)**2

'''

with open('c:/demo/test.py', 'w') as f:
    f.write(text)

from ansys.optislang.core import Optislang
from ansys.optislang.core import node_types
from ansys.optislang.core.project_parametric import ObjectiveCriterion
from ansys.optislang.core.tcp.osl_server import TcpOslServer
osl_server = TcpOslServer()
osl_server.new()
para = osl_server.create_node(node_types.AMOP.id)
python = osl_server.create_node(node_types.Python2.id, parent_uid=para)

osl_server.set_actor_property(python, 'AllowSpaceInFilePath', True)
prop = osl_server.get_actor_properties(python)
prop['Path']['path']['split_path']['head'] = 'c:/demo'
prop['Path']['path']['split_path']['tail'] = 'test.py'

osl_server.set_actor_property(python, 'Path', prop['Path'])
x = osl_server.get_actor_properties(python)

osl_server.connect_nodes(para, "IODesign", python, "IDesign")
osl_server.connect_nodes(python, "ODesign", para, "IIDesign")

osl_server.register_location_as_parameter(python, 'x1', 'x1', 0.1)
osl_server.register_location_as_parameter(python, 'x2', 'x2', 0.1)

osl_server.register_location_as_response(python, 'y', 'y', 0.1)
info = osl_server.get_actor_properties(para)

container = info['ParameterManager']['parameter_container']
container[0]['deterministic_property']['lower_bound'] = -5
container[0]['deterministic_property']['upper_bound'] = 5

container = info['ParameterManager']['parameter_container']
container[1]['deterministic_property']['lower_bound'] = -5
container[1]['deterministic_property']['upper_bound'] = 5

osl_server.set_actor_property(para, 'ParameterManager', info['ParameterManager'])

osl_server.save_as('c:/demo/example.opf')

osl_server.add_criterion(para, 'min', 'y', 'obj_0')


osl_server.dispose()

with Optislang(project_path='c:/demo/example.opf') as osl:
    osl.application.project.start()
