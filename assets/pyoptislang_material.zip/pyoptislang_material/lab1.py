if not 'OSL_REGULAR_EXECUTION' in locals(): 
    OSL_REGULAR_EXECUTION = False


if not OSL_REGULAR_EXECUTION:
    x1 = 0.1
    x2 = 0.1

y = (x1 -1)**2 + (x2 -3)**2