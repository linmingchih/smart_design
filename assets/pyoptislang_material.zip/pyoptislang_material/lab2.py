w = 0.5
dw = 0.1
t = 0.1
gap = 0.5
h = 0.3
sw = 1
sl = 2
n = 4

def get_cell(x):
    return [(x,sl,0),(x+sw,sl,0),(x+sw,0,0),(x+2*sw,0,0)]

pts = [(0,0,0), (2*sw,0,0)]
for i in range(n):
    x = pts[-1][0]
    pts += get_cell(x)

x, y, z = pts[-1]
pts.append((x+sw, y, z))

from pyaedt import Hfss
hfss = Hfss(version='2024.1')

hfss.modeler.model_units = 'mm'
line = hfss.modeler.create_polyline(pts,
                                    xsection_type='Isosceles Trapezoid',
                                    xsection_height=t,
                                    xsection_width=w,
                                    xsection_topwidth=w-dw,
                                    material='copper')

x0, y0, z0, x1, y1, z1 = line.bounding_box

box = hfss.modeler.create_box((0, y0-y1-w/2,-t/2), 
                              (x1, 3*(y1-y0), -h),
                              material = 'FR4_epoxy')

gnd = hfss.modeler.create_object_from_face(box.bottom_face_z)
hfss.modeler.thicken_sheet(gnd, 0.01)
gnd.material_name = 'copper'
region = hfss.modeler.create_region([0,0,0,0,1000,0])

port1 = hfss.wave_port(region.bottom_face_x, gnd.name)
port2 = hfss.wave_port(region.top_face_x, gnd.name)

setup = hfss.create_setup()
setup.props['Frequency'] = '2GHz'
setup.create_linear_step_sweep('GHz',0.001,2,0.1)

hfss.analyze(cores=4)
data = hfss.post.get_solution_data('dB(S(2,1))')
sdd21 = data.data_real()
freq = data.primary_sweep_values

hfss.post.create_report('dB(S(2,1))')