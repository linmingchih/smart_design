import subprocess
import psutil
import json

from pyvariant import list_2_variant_xy_data

if 'OSL_REGULAR_EXECUTION' not in locals(): 
    OSL_REGULAR_EXECUTION = False


if not OSL_REGULAR_EXECUTION:
    w = 0.5
    dw = 0.1
    t = 0.1
    gap = 0.5
    h = 0.3
    sw = 1
    sl = 2
    n = 4

process = subprocess.Popen(
    [r'C:\myvenv\Scripts\python.exe', 
    'c:\demo\lab3b.py', 
    str(w), 
    str(dw),
    str(t),
    str(gap),
    str(h),
    str(sw),
    str(sl),
    str(n)],
    text=True,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE
)

try:
    stdout, stderr = process.communicate(timeout=120)
    if process.returncode == 0:
        print("Success:", stdout)
        try:
            with open('c:/demo/serpentine.json') as f:
                x, y = json.load(f)

            variant_y = list_2_variant_xy_data(y, x)
        except Exception as e:
            print(f"Error parsing output: {e}")
    else:
        print(f"Error running script: {stderr}")
except subprocess.TimeoutExpired:
    print("Process timed out")
    process.terminate()

    for proc in psutil.process_iter(['pid', 'name']):
        if proc.info['name'] == "ansysedt.exe":
            proc.kill()
            print(f"Terminated {proc.info['name']} with PID {proc.info['pid']}")
