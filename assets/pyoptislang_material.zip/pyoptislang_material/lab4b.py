import sys
sys.path.append(r"C:\demo")

from mopsolver import MOPSolver
osl_install_path = r'C:\Program Files\ANSYS Inc\v241\optiSLang'
omdb_file = r"c:\demo\example.opd\AMOP\AMOP.omdb"

solver = MOPSolver(osl_install_path, omdb_file)

print(solver)
print(solver.run([[4,-4],[-4,4]]))
