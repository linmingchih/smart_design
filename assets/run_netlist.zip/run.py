import os

directory = 'd:/demo'

oDesktop.ClearMessages("", "", 2)
os.chdir(directory)
for cir in os.listdir(directory):
    if not cir.endswith('.cir'):
        continue
    
    cir_path = os.path.join(directory, cir)
    csv_path = cir_path.replace('.cir', '.csv')
    
    oDesktop.OpenProject(cir_path)
    oProject = oDesktop.GetActiveProject()
    oDesign = oProject.GetActiveDesign()
    
    oDesign.AnalyzeAll()
    oModule = oDesign.GetModule("ReportSetup")
    oModule.GetAllCategories("Standard", "Data Table", "TRAN", "",)
    quantities = oModule.GetAllQuantities("Standard", "Data Table", "TRAN", "", 'Voltage')
    
    oModule.CreateReport("Transient Voltage Table", "Standard", "Data Table", "TRAN", 
     	[
    		"NAME:Context",
    		"SimValueContext:="	, [1,0,2,0,False,False,-1,1,0,1,1,"",0,0,"DE",False,"0"]
     	], 
     	[
    		"Time:="		, ["All"]
     	], 
     	[
    		"X Component:="		, "Time",
    		"Y Component:="		, quantities
     	])
    
    oModule.ExportToFile("Transient Voltage Table", csv_path, False)
    AddWarningMessage('save {}!'.format(csv_path))
    oProject.Close()
