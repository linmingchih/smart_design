### ✅ **最高層級目標 (Overarching Goal)**

你將扮演一位資深的自動化模擬工程師，你的核心任務是使用 Python 和 PyEDB 套件，開發一個**模組化、可測試**的完整自動化解決方案，以管理 ANSYS EDB 專案中的 PCB 堆疊資訊。此方案的關鍵是實現 PCB 堆疊數據在 EDB 格式與 Excel 格式之間的雙向、無損轉換，並最終透過一個簡易的 Web UI 提供給終端使用者。

### 📖 **Workflow 總覽**

整個自動化流程應嚴格遵循以下順序：

1.  **匯出 (Export)**: 使用者提供一個 `.brd` 檔，系統呼叫一個獨立函式，將其轉換為 `.aedb` 專案，並從中提取詳細的堆疊資訊，生成一個標準化的 Excel 檔案 (`stackup_report.xlsx`)。
2.  **手動編輯 (Manual Edit)**: 使用者直接在 Excel 中修改堆疊參數。
3.  **匯入 (Import)**: 系統呼叫另一個獨立函式，讀取使用者修改後的 Excel 檔案，並將變更內容精確地寫回 `.aedb` 專案，生成一個更新後的版本。
4.  **單元/整合測試 (Unit/Integration Test)**: 一個自動化測試腳本將**導入**上述函式，驗證後端核心邏輯是否準確無誤。
5.  **UI 測試 (UI Test)**: 一個使用 Selenium 的自動化測試腳本將模擬使用者操作，驗證 Web UI 的完整流程。
6.  **使用者介面 (UI)**: 提供一個簡易的 Web 介面，讓非開發人員也能輕鬆執行匯出與匯入的操作。

---

### 🧠 **任務一：撰寫 `export_stackup_to_excel.py`**

**目標**：建立一個包含核心匯出邏輯的 Python 腳本，該腳本既可以被其他程式導入，也可以獨立執行。

**檔案結構與需求**:

1.  **函式定義 (Function Definition)**:
    * 將所有核心邏輯封裝在一個函式中。
    * **函式簽名 (Signature)**:
        ```python
        def export_stackup_to_excel(brd_path: str, output_excel_path: str, unit: str = 'mil', edb_version: str = "2024.1") -> bool:
            """
            從 .brd 檔案讀取 PCB 堆疊資訊，並將其匯出為一個結構化的 Excel 檔案。
            :param brd_path: 輸入的 .brd 檔案路徑。
            :param output_excel_path: 輸出的 Excel 檔案路徑。
            :param unit: 厚度輸出的單位，可以是 'mil' 或 'mm'。
            :param edb_version: 使用的 EDB 版本。
            :return: 如果成功則返回 True，否則返回 False。
            """
            # ... 實作程式碼 ...
        ```

2.  **執行邏輯 (Execution Logic)**:
    * 在函式內部，執行 EDB 轉換、數據提取、整理，並使用 `pandas` 寫入 Excel。
    * 遵循下方的 **Excel 輸出規格** 與 **特殊格式化規則**。

3.  **獨立執行區塊 (Standalone Execution)**:
    * 在檔案末尾加入 `if __name__ == "__main__":` 區塊。
    * 此區塊的目的是為了方便單獨測試此腳本。它應該包含：
        * 定義測試用的輸入 `.brd` 路徑和輸出 Excel 路徑。
        * 呼叫 `export_stackup_to_excel()` 函式。
        * 根據回傳結果，印出成功或失敗的訊息。

**Excel 輸出規格**：

| 欄位名稱 (Column Header) | 英文名稱 (Suggested Key) | 內容說明與提取規則 |
| :--- | :--- | :--- |
| **層名稱** | `Layer Name` | 直接讀取層的名稱。 |
| **層類型** | `Layer Type` | 讀取層的類型，例如 `Signal`、`Dielectric`。 |
| **厚度 (`unit`)** | `Thickness (mil)` 或 `Thickness (mm)` | **注意**: 此欄位的標頭與數值會根據 `unit` 參數動態決定。提取出的厚度單位為 `meter`，需根據 `unit` 參數轉換後再寫入。 |
| **介電常數** | `Dielectric Constant (Dk)` | 從該層對應的材料中讀取 `permittivity`。 |
| **損耗係數** | `Loss Tangent (Df)` | 從該層對應的材料中讀取 `loss_tangent`。 |
| **導電率** | `Conductivity` | 從該層對應的材料中讀取 `conductivity`。 |
| **蝕刻係數** | `Etching Factor` | 讀取層的 `etch_factor`。**如果讀到的值是 `0`，仍需顯示 `0`**。 |
| **頂層節點半徑 (µm)** | `Top Nodule Radius (um)` | 讀取 Huray 模型的 `top_hallhuray_nodule_radius`，單位為 `µm`。 |
| **頂層表面係數** | `Top Surface Ratio` | 讀取 Huray 模型的 `top_hallhuray_surface_ratio`。 |
| **底層節點半徑 (µm)**| `Bottom Nodule Radius (um)` | 讀取 Huray 模型的 `bottom_hallhuray_nodule_radius`，單位為 `µm`。 |
| **底層表面係數**| `Bottom Surface Ratio` | 讀取 Huray 模型的 `bottom_hallhuray_surface_ratio`。 |
| **側邊節點半徑 (µm)**| `Side Nodule Radius (um)` | 讀取 Huray 模型的 `side_hallhuray_nodule_radius`，單位為 `µm`。 |
| **側邊表面係數**| `Side Surface Ratio` | 讀取 Huray 模型的 `side_hallhuray_surface_ratio`。 |

**特殊格式化規則 (Mandatory)**：
* 不需要輸出材料名稱欄位
* 對於**訊號層 (Signal Layer)**: `Dk` 和 `Df` 欄位必須為**空值**，並將其儲存格背景填充為**白色**。絕不能填入 `0` 或 `None`。
* 對於**介電層 (Dielectric Layer)**: `Conductivity`、`Etching Factor` 及所有 `Roughness` 相關欄位必須為**空值**，並將其儲存格背景填充為**白色**。

---

### 🧠 **任務二：撰寫 `import_stackup_from_excel.py`**

**目標**：建立一個包含核心匯入邏輯的 Python 腳本，同樣地，它既可以被其他程式導入，也可以獨立執行。

**檔案結構與需求**:

1.  **函式定義 (Function Definition)**:
    * 將所有核心邏輯封裝在一個函式中。
    * **函式簽名 (Signature)**:
        ```python
        def import_stackup_from_excel(edb_path: str, excel_path: str, output_aedb_path: str, edb_version: str = "2024.1") -> bool:
            """
            讀取 Excel 檔案，並根據其內容更新 EDB 專案的堆疊設定。
            此函式會讀取.aedb 作為基礎。
            :param aedb_path: 作為基礎設計的 .aedb 檔案路徑。
            :param excel_path: 包含堆疊修改資訊的 Excel 檔案路徑。
            :param output_aedb_path: 更新後要儲存的 .aedb 專案路徑。
            :param edb_version: 使用的 EDB 版本。
            :return: 如果成功則返回 True，否則返回 False。
            """
            # ... 實作程式碼 ...
        ```

2.  **執行邏輯 (Execution Logic)**:
    * 在函式內部，嚴格遵循以下**處理邏輯與順序**。
    * 首先從 `edb_path` 建立一個 EDB 物件，然後根據 `excel_path` 的內容對其進行修改，最後儲存到 `output_aedb_path`。

3.  **處理邏輯與順序 (非常重要)**:
    * **厚度更新**: 腳本必須能動態讀取厚度欄位。它需要檢查 Excel 中是否存在 `Thickness (mil)` 或 `Thickness (mm)` 欄位，並根據找到的欄位名稱來判斷單位，然後將其值**精確轉換為 `meter`**，再更新至 `layer.thickness`。
    * **材料處理**:
        * 對於**介電層**：根據 `Dk` 和 `Df` 產生材料名稱 (`m_{Dk}_{Df}`)。若材料不存在，則建立；反之則直接使用。
        * 對於**導電層**：根據 `Conductivity` 產生材料名稱 (如 `cond_{Conductivity}`）。若材料不存在，則建立；反之則直接使用。
    * **蝕刻係數更新**: 將 `layer.etch_factor` 更新為 Excel 中 `Etching Factor` 欄位提供的值，**即使該值為 0**。
    * **粗糙度模型更新**:
        * **啟用條件 (必須同時滿足)**:
            1.  Excel 中該層的 `Etching Factor` **不為 0** 且非空。
            2.  Excel 中該層的六個 Huray 粗糙度參數中，**至少有一個不為 0** 且非空。
        * **執行動作**: 若上述條件滿足，則設定 `layer.roughness_enabled = True`，並根據 Excel 中的值，分別對 `"top"`, `"bottom"`, `"side"` 三個表面呼叫 `layer.assign_roughness_model()`。
    * **填充材料更新**:
        * 識別所有訊號層並排序。令總數為 `n`。
        * 對於**前半部分**的訊號層（索引 `0` 到 `ceil(n/2) - 1`），其 `Fill Material` 設定為其**正上方**介電層的材料。
        * 對於**後半部分**的訊號層，其 `Fill Material` 設定為其**正下方**介電層的材料。

4.  **獨立執行區塊 (Standalone Execution)**:
    * 在檔案末尾加入 `if __name__ == "__main__":` 區塊。
    * 此區塊應包含：
        * 定義測試用的輸入 `.brd` 路徑、Excel 路徑和輸出 `.aedb` 路徑。
        * 呼叫 `import_stackup_from_excel()` 函式。
        * 根據回傳結果，印出成功或失敗的訊息。

---

### 🧠 **任務三：撰寫 `test_excel_to_aedb.py`**

**目標**：建立一個自動化測試腳本，透過**導入**前兩個腳本中的函式，以程式化的方式驗證後端核心邏輯是否完全正確。

**測試流程**:

1.  **導入函式**:
    * 在腳本開頭，從 `export_stackup_to_excel` 模組導入 `export_stackup_to_excel` 函式。
    * 從 `import_stackup_from_excel` 模組導入 `import_stackup_from_excel` 函式。
2.  **測試函式定義**:
    * 將整個測試流程封裝在一個或多個測試函式中，例如 `def test_stackup_roundtrip()`。
    * **注意**: 測試應涵蓋 `unit='mil'` 和 `unit='mm'` 兩種情況，確保匯出和匯入的流程在兩種單位下都能正確運作。
3.  **執行步驟**:
    1.  **前置作業**: 呼叫 `export_stackup_to_excel()`，基於原始 `.brd` 檔案生成一份乾淨的 `stackup_report.xlsx` 作為測試基準。
    2.  **數據篡改 (Data Tampering)**:
        * 使用 `pandas` 載入 `stackup_report.xlsx`。
        * **隨機**選擇一個**導電層**，並修改其厚度、`Etching Factor`、`Top Surface Ratio` 等值。
        * **隨機**選擇一個**介電層**，並修改其 `Dielectric Constant (Dk)`。
        * 儲存被篡改後的 Excel。
    3.  **執行匯入**: 呼叫 `import_stackup_from_excel()`，讓它基於被篡改的 Excel 和原始 `.brd` 生成 `updated_stackup.aedb`。
    4.  **驗證 (Validation)**:
        * 使用 `pyedb` 重新載入 `updated_stackup.aedb`。
        * 定位到被修改的層，使用 `assert` 語句驗證其屬性是否與篡改後的值**完全一致**（注意單位換算後的浮點數精度問題）。
    5.  **日誌記錄**: 無論成功或失敗，都要輸出清晰的 Log。
    6.  **清理 (Cleanup)**: 測試結束後，自動刪除所有生成的臨時檔案。
4.  **獨立執行區塊**:
    * 在檔案末尾加入 `if __name__ == "__main__":` 區塊，呼叫 `test_stackup_roundtrip()` 函式來執行測試。

---

### 🧠 **任務四：建構 Web UI**

**目標**: 使用 Flask 和 Bootstrap 建立一個極簡的 Web 使用者介面，封裝已建立的函式。

**主要功能與路由 (Routes)**:

1.  **路由: `/` 或 `/index`**
    * **功能**: 顯示主頁，包含兩個獨立的檔案上傳表單。
    * **介面**: 標題、簡要說明、一個標示為 "步驟一：上傳 .brd 以匯出 Excel" 的區塊，以及一個標示為 "步驟二：上傳 Excel 與 .brd 以更新設計" 的區塊。
2.  **路由: `/upload_brd` (接受 `POST` 請求)**
    * **處理流程**: 在後端呼叫已定義的 `export_stackup_to_excel` 函式。
3.  **路由: `/upload_excel` (接受 `POST` 請求)**
    * **處理流程**: 在後端呼叫已定義的 `import_stackup_from_excel` 函式，並將生成的 `.aedb` 目錄壓縮成 `.zip` 回傳。

---

### 🧠 **任務五：撰寫 `test_web_ui.py` (使用 Selenium)**

**目標**：建立一個端對端 (End-to-End) 的自動化測試腳本，模擬真實使用者操作，驗證 Web UI 的完整工作流程。

**測試框架與工具**:
* **測試框架**: `pytest`
* **瀏覽器自動化**: `selenium`
* **WebDriver**: 需要預先安裝對應瀏覽器的 WebDriver (例如 `chromedriver`)。

**測試流程**:
1.  **前置設定 (Setup)**:
    * 在測試開始前，於背景執行緒或獨立程序中啟動 Flask 應用程式。
    * 初始化 Selenium WebDriver，並設定好下載路徑以便後續驗證。
2.  **測試案例一：匯出 Excel 流程 (`/upload_brd`)**
    1.  瀏覽器導向至網站根目錄 (`/`)。
    2.  使用 Selenium 定位到「步驟一」表單中的檔案上傳欄位 (`<input type="file">`)。
    3.  使用 `send_keys()` 方法，將測試用 `.brd` 檔案的絕對路徑傳入。
    4.  點擊「匯出 Excel」按鈕。
    5.  **驗證**: 檢查指定的下載路徑中，是否成功下載了 `stackup_report.xlsx` 檔案。斷言 (Assert) 檔案存在。
3.  **測試案例二：匯入並更新 AEDB 流程 (`/upload_excel`)**
    1.  瀏覽器導向至網站根目錄 (`/`)。
    2.  定位到「步驟二」表單中的兩個檔案上傳欄位。
    3.  使用 `send_keys()` 將測試用 `.brd` 檔案和修改後的 `stackup_report.xlsx` 的路徑分別傳入。
    4.  點擊「更新 AEDB 並下載」按鈕。
    5.  **驗證**: 檢查指定的下載路徑中，是否成功下載了包含 `.aedb` 的 `.zip` 檔案。斷言 (Assert) 檔案存在。
4.  **後置清理 (Teardown)**:
    * 測試結束後，關閉 Selenium WebDriver (`driver.quit()`)。
    * 終止背景執行的 Flask 應用程式。
    * 清理所有在測試過程中產生的臨時檔案（如下載的 Excel 和 zip 檔）。

---

### 📋 **開發環境、資源與通用要求**

* **執行環境**:
    * 所有程式碼需在 `.venv` 虛擬環境下執行。
    * 可自行安裝所需套件，但必須在 `requirements.txt` 中列出。
    * 測試檔案：使用目錄當中提供的 `Galileo_G87173_204.brd` 進行開發與測試。
* **最佳實踐**:
    * **日誌 (Logging)**: 所有腳本都應包含詳細的日誌輸出。
    * **程式碼註解**: 在複雜的邏輯區塊添加清晰的註解。
    * **資料驗證**: 在 `import` 函式中加入基本的資料驗證。

---

### 🔧 **附註：參考 API (Appendix: Reference API)**

以下是您提供且已驗證可用的 API 片段，可作為開發的起點。

#### **讀取 (Read) API 範例**
```python
from pyedb import Edb

# 假設 brd_path 已被定義
# brd_path = r"Galileo_G87173_204.brd"

edb = Edb(brd_path, edbversion='2024.1')

for layer_name, layer in edb.stackup.layers.items():
    print(f"--- Layer: {layer_name} ---")
    print(f"Type: {layer.type}")
    print(f"Thickness: {layer.thickness} meter")
    print(f"Etch Factor: {layer.etch_factor}")
    
    # 讀取 Huray 粗糙度模型參數
    print(f"Top Nodule Radius: {layer.top_hallhuray_nodule_radius}")
    print(f"Top Surface Ratio: {layer.top_hallhuray_surface_ratio}")
    print(f"Bottom Nodule Radius: {layer.bottom_hallhuray_nodule_radius}")
    print(f"Bottom Surface Ratio: {layer.bottom_hallhuray_surface_ratio}")
    print(f"Side Nodule Radius: {layer.side_hallhuray_nodule_radius}")
    print(f"Side Surface Ratio: {layer.side_hallhuray_surface_ratio}")
    
    # 讀取材料屬性
    if layer.material:
        material = edb.materials.materials[layer.material]
        print(f"Material Permittivity (Dk): {material.permittivity}")
        print(f"Material Loss Tangent (Df): {material.loss_tangent}")
        print(f"Material Conductivity: {material.conductivity}")
    
edb.close_edb()

```
#### **編輯 (Edit) API 範例**

```
from pyedb import Edb

# 假設 edb_path 和 new_edb_path 已被定義
# edb_path = "path/to/your.aedb"
# new_edb_path = "path/to/your_updated.aedb"

# 建議從 .brd 開始，以確保 aedb 專案是乾淨的
# edb = Edb(brd_path, edbversion='2024.1')
edb = Edb(edb_path, edbversion='2024.1')


# 建立新的導電材料
m1 = edb.materials.add_conductor_material('cond1', conductivity=5e7)

# 建立新的介電材料
m2 = edb.materials.add_dielectric_material('dielectric1', permittivity=3, dielectric_loss_tangent=0.03)

for layer_name, layer in edb.stackup.layers.items():
    # 修改層的厚度 (單位：meter)
    layer.thickness = 0.003
    
    # 修改蝕刻係數
    layer.etch_factor = 2
    
    # 啟用粗糙度
    layer.roughness_enabled = True
    
    # 設定填充材料
    if layer.type == "signal":
        layer.fill_material = m2.name
    
    # 設定層材料
    if layer.type == "signal":
        layer.material = m1.name
    elif layer.type == "dielectric":
        layer.material = m2.name

    # 設定粗糙度模型 (可分別對 "top", "bottom", "side" 設定)
    layer.assign_roughness_model(
        model_type="huray",
        huray_radius="0.5um",
        huray_surface_ratio="2.9",
        apply_on_surface="top"
    )

# 儲存為新的 aedb 專案
edb.save_edb_as(new_edb_path)
edb.close_edb()
```
