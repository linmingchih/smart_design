import os
import shutil
import zipfile
from flask import Flask, request, render_template, send_from_directory, flash, redirect, url_for, session, make_response
from werkzeug.utils import secure_filename
import logging
import webbrowser
import threading

# Import core logic
from .logic.export_stackup_to_excel import export_stackup_to_excel
import multiprocessing
from .worker import import_worker

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Define upload and output folders
UPLOAD_FOLDER = 'uploads'
OUTPUT_FOLDER = 'outputs'
ALLOWED_EXTENSIONS_BRD = {'brd'}
ALLOWED_EXTENSIONS_EXCEL = {'xlsx'}

# Create Flask app
app = Flask(__name__, template_folder='../templates')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['OUTPUT_FOLDER'] = OUTPUT_FOLDER
app.config['SECRET_KEY'] = 'supersecretkey' # Necessary for flashing messages

# Ensure the upload and output directories exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

def allowed_file(filename, allowed_extensions):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload_brd', methods=['POST'])
def handle_brd_upload():
    if 'brd_file' not in request.files or request.files['brd_file'].filename == '':
        response = make_response(redirect(url_for('index')))
        response.set_cookie('flashMessage', 'No file selected.', max_age=20)
        response.set_cookie('messageTarget', 'brd', max_age=20)
        return response

    file = request.files['brd_file']
    unit = request.form.get('unit', 'mil')

    if allowed_file(file.filename, ALLOWED_EXTENSIONS_BRD):
        filename = secure_filename(file.filename)
        brd_path_abs = os.path.abspath(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        file.save(brd_path_abs)

        aedb_name = os.path.splitext(filename)[0] + '.aedb'
        aedb_path_abs = os.path.abspath(os.path.join(app.config['UPLOAD_FOLDER'], aedb_name))
        session['source_aedb_path'] = aedb_path_abs

        output_excel_name = f"{os.path.splitext(filename)[0]}_stackup_{unit}.xlsx"
        output_excel_path_abs = os.path.abspath(os.path.join(app.config['OUTPUT_FOLDER'], output_excel_name))

        logging.info(f"Starting export for {brd_path_abs} to {output_excel_path_abs}")
        success, message = export_stackup_to_excel(brd_path_abs, output_excel_path_abs, unit=unit)

        if success:
            logging.info(f"Export successful. Sending file: {output_excel_name}")
            success_message = f"Export successful! Project '{aedb_name}' is ready for Step 2."
            response = make_response(send_from_directory(os.path.abspath(app.config['OUTPUT_FOLDER']), output_excel_name, as_attachment=True))
            response.set_cookie('fileDownload', 'true', max_age=20)
            response.set_cookie('flashMessage', success_message, max_age=20)
            response.set_cookie('messageTarget', 'brd', max_age=20)
            return response
        else:
            response = make_response(redirect(url_for('index')))
            response.set_cookie('flashMessage', f'Export failed: {message}', max_age=20)
            response.set_cookie('messageTarget', 'brd', max_age=20)
            return response
    else:
        response = make_response(redirect(url_for('index')))
        response.set_cookie('flashMessage', 'Invalid file type. Please upload a .brd file.', max_age=20)
        response.set_cookie('messageTarget', 'brd', max_age=20)
        return response


@app.route('/upload_excel', methods=['POST'])
def handle_excel_upload():
    source_aedb_path = session.get('source_aedb_path')
    if not source_aedb_path or not os.path.exists(source_aedb_path):
        response = make_response(redirect(url_for('index')))
        response.set_cookie('flashMessage', 'Could not find the base .aedb project. Please complete Step 1 first.', max_age=20)
        response.set_cookie('messageTarget', 'excel', max_age=20)
        return response

    if 'excel_file' not in request.files or request.files['excel_file'].filename == '':
        response = make_response(redirect(url_for('index')))
        response.set_cookie('flashMessage', 'No Excel file selected.', max_age=20)
        response.set_cookie('messageTarget', 'excel', max_age=20)
        return response

    excel_file = request.files['excel_file']

    if allowed_file(excel_file.filename, ALLOWED_EXTENSIONS_EXCEL):
        excel_filename = secure_filename(excel_file.filename)
        excel_path_abs = os.path.abspath(os.path.join(app.config['UPLOAD_FOLDER'], excel_filename))
        excel_file.save(excel_path_abs)

        aedb_basename = os.path.basename(source_aedb_path)
        output_aedb_name = f"updated_{os.path.splitext(aedb_basename)[0]}.aedb"
        output_aedb_path_abs = os.path.abspath(os.path.join(app.config['OUTPUT_FOLDER'], output_aedb_name))

        logging.info(f"Spawning worker process for import: '{excel_path_abs}' to '{output_aedb_path_abs}'")
        queue = multiprocessing.Queue()
        process = multiprocessing.Process(target=import_worker, args=(queue, source_aedb_path, excel_path_abs, output_aedb_path_abs))
        process.start()
        process.join(timeout=180)

        if process.is_alive():
            process.terminate()
            process.join()
            success = False
            message = "Import process timed out and was terminated."
            logging.error(message)
        else:
            success, message = (False, "Process crashed.") if queue.empty() else queue.get()

        if success:
            zip_name = f"{os.path.splitext(output_aedb_name)[0]}.zip"
            zip_path_abs = os.path.abspath(os.path.join(app.config['OUTPUT_FOLDER'], zip_name))
            shutil.make_archive(os.path.splitext(zip_path_abs)[0], 'zip', output_aedb_path_abs)
            logging.info(f"Import successful. Sending zipped file: {zip_name}")

            response = make_response(send_from_directory(os.path.abspath(app.config['OUTPUT_FOLDER']), zip_name, as_attachment=True))
            response.set_cookie('fileDownload', 'true', max_age=20)
            response.set_cookie('flashMessage', 'Import successful! Your updated project is downloading.', max_age=20)
            response.set_cookie('messageTarget', 'excel', max_age=20)
            return response
        else:
            response = make_response(redirect(url_for('index')))
            response.set_cookie('flashMessage', f'Import failed: {message}', max_age=20)
            response.set_cookie('messageTarget', 'excel', max_age=20)
            return response
    else:
        response = make_response(redirect(url_for('index')))
        response.set_cookie('flashMessage', 'Invalid file type. Please use a .xlsx file.', max_age=20)
        response.set_cookie('messageTarget', 'excel', max_age=20)
        return response

if __name__ == '__main__':
    # Required for multiprocessing on Windows
    multiprocessing.freeze_support()
    # Open a web browser to the app's URL after a short delay
    threading.Timer(1, lambda: webbrowser.open_new("http://127.0.0.1:5000/")).start()
    app.run(debug=True, use_reloader=False)
