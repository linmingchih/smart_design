
import logging
from .logic.import_stackup_from_excel import import_stackup_from_excel

# Configure logging for the worker process
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def import_worker(queue, edb_path, excel_path, output_aedb_path):
    """
    A worker function designed to be run in a separate process to isolate the EDB call.
    """
    try:
        logging.info("[Worker] Starting import process...")
        success, message = import_stackup_from_excel(
            edb_path=edb_path,
            excel_path=excel_path,
            output_aedb_path=output_aedb_path
        )
        logging.info(f"[Worker] Import process finished with success: {success}")
        queue.put((success, message))
    except Exception as e:
        # This will catch any unexpected errors within the import function itself
        error_msg = f"[Worker] An unexpected exception occurred: {e}"
        logging.error(error_msg, exc_info=True)
        queue.put((False, str(e)))

