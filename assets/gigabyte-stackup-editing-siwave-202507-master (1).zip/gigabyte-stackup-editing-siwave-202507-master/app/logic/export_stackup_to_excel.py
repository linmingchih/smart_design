
import os
import pandas as pd
from pyedb import Edb
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def export_stackup_to_excel(brd_path: str, output_excel_path: str, unit: str = 'mil', edb_version: str = "2024.1") -> (bool, str):
    """
    從 .brd 檔案讀取 PCB 堆疊資訊，並將其匯出為一個結構化的 Excel 檔案。
    :param brd_path: 輸入的 .brd 檔案路徑。
    :param output_excel_path: 輸出的 Excel 檔案路徑。
    :param unit: 厚度輸出的單位，可以是 'mil' 或 'mm'。
    :param edb_version: 使用的 EDB 版本。
    :return: A tuple (bool, str) indicating success and a message.
    """
    if not os.path.exists(brd_path):
        msg = f"Input file not found: {brd_path}"
        logging.error(msg)
        return False, msg

    if unit not in ['mil', 'mm']:
        msg = f"Invalid unit specified: {unit}. Must be 'mil' or 'mm'."
        logging.error(msg)
        return False, msg

    # Define conversion factors from meter
    unit_conversions = {
        'mil': 39370.1,
        'mm': 1000
    }
    conversion_factor = unit_conversions[unit]
    thickness_col_name = f'Thickness ({unit})'
    
    # To avoid issues with temporary file paths, we'll create the .aedb in the same directory as the output
    output_dir = os.path.dirname(brd_path)
    aedb_path = os.path.join(output_dir, os.path.basename(brd_path).replace('.brd', '.aedb'))

    edb = None
    try:
        logging.info(f"Opening .brd file and creating EDB project at: {aedb_path}")
        # The aedb_path will be created by Edb based on the brd_path
        edb = Edb(brd_path, edbversion=edb_version)
        
        stackup_data = []
        
        # Sort layers by their order in the stackup, in descending order to have TOP at the top
        sorted_layers = sorted(edb.stackup.layers.values(), key=lambda x: x.id, reverse=True)

        for layer in sorted_layers:
            layer_name = layer.name
            layer_type = layer.type
            
            # Initialize data dictionary with common values
            data = {
                'Layer Name': layer_name,
                'Layer Type': layer_type,
                thickness_col_name: layer.thickness * conversion_factor if layer.thickness is not None else None,
                'Dielectric Constant (Dk)': None,
                'Loss Tangent (Df)': None,
                'Conductivity': None,
                'Etching Factor': None,
                'Top Nodule Radius (um)': None,
                'Top Surface Ratio': None,
                'Bottom Nodule Radius (um)': None,
                'Bottom Surface Ratio': None,
                'Side Nodule Radius (um)': None,
                'Side Surface Ratio': None,
            }

            material = edb.materials.materials.get(layer.material)

            if layer_type == 'signal':
                if material:
                    data['Conductivity'] = material.conductivity
                data['Etching Factor'] = layer.etch_factor if layer.etch_factor is not None else 0
                
                # Huray model parameters are already in the correct units (um) or ratio
                data['Top Nodule Radius (um)'] = layer.top_hallhuray_nodule_radius
                data['Top Surface Ratio'] = layer.top_hallhuray_surface_ratio
                data['Bottom Nodule Radius (um)'] = layer.bottom_hallhuray_nodule_radius
                data['Bottom Surface Ratio'] = layer.bottom_hallhuray_surface_ratio
                data['Side Nodule Radius (um)'] = layer.side_hallhuray_nodule_radius
                data['Side Surface Ratio'] = layer.side_hallhuray_surface_ratio

            elif layer_type == 'dielectric':
                if material:
                    data['Dielectric Constant (Dk)'] = material.permittivity
                    data['Loss Tangent (Df)'] = material.loss_tangent
            
            stackup_data.append(data)

        logging.info("Successfully extracted stackup data.")

        # Create DataFrame and save to Excel
        df = pd.DataFrame(stackup_data)
        
        # Reorder columns to match specification, ensuring thickness column is third
        columns = [
            'Layer Name', 'Layer Type', thickness_col_name, 'Dielectric Constant (Dk)', 
            'Loss Tangent (Df)', 'Conductivity', 'Etching Factor', 
            'Top Nodule Radius (um)', 'Top Surface Ratio', 'Bottom Nodule Radius (um)', 
            'Bottom Surface Ratio', 'Side Nodule Radius (um)', 'Side Surface Ratio'
        ]
        df = df[columns]

        # Using openpyxl engine to handle cell styling if needed in the future
        # For now, just writing the data. The empty values are handled by the logic above.
        df.to_excel(output_excel_path, index=False, engine='openpyxl')
        
        logging.info(f"Stackup report successfully exported to: {output_excel_path}")
        return True, "Export successful."

    except Exception as e:
        msg = f"An error occurred during the export process: {e}"
        logging.error(msg, exc_info=True)
        return False, msg
    finally:
        if edb:
            edb.close_edb()
            logging.info("EDB project closed.")


if __name__ == '__main__':
    # Define paths for standalone execution
    # Using absolute paths for clarity
    current_dir = os.path.dirname(os.path.abspath(__file__))
    brd_file_path = os.path.join(current_dir, 'Galileo_G87173_204.brd')
    excel_output_path = os.path.join(current_dir, 'stackup_report.xlsx')

    logging.info("--- Running Export Stackup Script in Standalone Mode ---")
    
    # Check if the required .brd file exists
    if not os.path.exists(brd_file_path):
        logging.error(f"Test file not found: {brd_file_path}")
        logging.error("Please ensure 'Galileo_G87173_204.brd' is in the same directory as this script.")
    else:
        # Call the function with 'mil' unit
        logging.info(f"Exporting stackup to {excel_output_path} with units in 'mil'.")
        success = export_stackup_to_excel(
            brd_path=brd_file_path,
            output_excel_path=excel_output_path,
            unit='mil'
        )

        if success:
            logging.info("--- Export process completed successfully. ---")
        else:
            logging.error("--- Export process failed. ---")
            
        # Example for 'mm' unit
        excel_output_path_mm = os.path.join(current_dir, 'stackup_report_mm.xlsx')
        logging.info(f"Exporting stackup to {excel_output_path_mm} with units in 'mm'.")
        success_mm = export_stackup_to_excel(
            brd_path=brd_file_path,
            output_excel_path=excel_output_path_mm,
            unit='mm'
        )
        if success_mm:
            logging.info("--- MM unit export process completed successfully. ---")
        else:
            logging.error("--- MM unit export process failed. ---")

