
import os
import pandas as pd
import numpy as np
from pyedb import Edb
import logging
import math
import re

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def import_stackup_from_excel(edb_path: str, excel_path: str, output_aedb_path: str, edb_version: str = "2024.1") -> (bool, str):
    """
    讀取 Excel 檔案，並根據其內容更新現有的 EDB 專案的堆疊設定。
    :param edb_path: 作為基礎設計的 .aedb 專案路徑。
    :param excel_path: 包含堆疊修改資訊的 Excel 檔案路徑。
    :param output_aedb_path: 更新後要儲存的 .aedb 專案路徑。
    :param edb_version: 使用的 EDB 版本。
    :return: A tuple (bool, str) indicating success and a message.
    """
    if not os.path.exists(edb_path) or not os.path.exists(excel_path):
        msg = f"Input file not found: {edb_path} or {excel_path}"
        logging.error(msg)
        return False, msg

    edb = None
    try:
        # 1. Load data from Excel
        df = pd.read_excel(excel_path).replace({np.nan: None})
        logging.info(f"Successfully loaded Excel file: {excel_path}")

        # 2. Open the existing EDB project
        logging.info(f"Opening base EDB project from: {edb_path}")
        edb = Edb(edb_path, edbversion=edb_version)
        logging.info(f"Successfully opened EDB project.")
        
        # Add detailed logging to check if layers are accessible
        try:
            num_layers = len(edb.stackup.layers)
            logging.info(f"Found {num_layers} layers in the EDB project.")
            if num_layers == 0:
                raise ValueError("No layers found in the source EDB project. The project may be empty or corrupted.")
        except Exception as e:
            raise RuntimeError(f"Failed to read layers from EDB project: {e}")

        # 3. Determine thickness unit from header
        thickness_col = next((col for col in df.columns if 'Thickness' in col), None)
        if not thickness_col:
            raise ValueError("Thickness column not found in Excel file.")
        
        unit_match = re.search(r'\((\w+)\)', thickness_col)
        if not unit_match:
            raise ValueError("Could not determine units from thickness column header.")
        unit = unit_match.group(1)

        unit_conversions_to_meter = {'mil': 0.0000254, 'mm': 0.001}
        if unit not in unit_conversions_to_meter:
            raise ValueError(f"Unsupported unit '{unit}' in thickness column.")
        conversion_factor = unit_conversions_to_meter[unit]
        logging.info(f"Detected unit from Excel: {unit}")

        # --- Layer Modification Loop ---
        all_layers = sorted(edb.stackup.layers.values(), key=lambda x: x.id, reverse=True)
        layer_map = {layer.name: layer for layer in all_layers}

        for index, row in df.iterrows():
            layer_name = row['Layer Name']
            if layer_name not in layer_map:
                logging.warning(f"Layer '{layer_name}' from Excel not found in EDB project. Skipping.")
                continue
            
            layer = layer_map[layer_name]
            logging.info(f"Processing layer: {layer_name}")

            # Update Thickness
            thickness_val = row.get(thickness_col)
            if thickness_val is not None:
                thickness_in_meters = thickness_val * conversion_factor
                # Round to 9 decimal places for high precision (nanometer level)
                layer.thickness = round(thickness_in_meters, 9)

            # Update Materials
            if layer.type == 'dielectric':
                dk = row.get('Dielectric Constant (Dk)')
                df_val = row.get('Loss Tangent (Df)')
                if dk is not None and df_val is not None:
                    mat_name = f"diel_{str(dk).replace('.', '_')}_{str(df_val).replace('.', '_')}"
                    if not edb.materials.materials.get(mat_name):
                        logging.info(f"Creating new dielectric material: {mat_name}")
                        edb.materials.add_dielectric_material(mat_name, permittivity=dk, dielectric_loss_tangent=df_val)
                    layer.material = mat_name

            elif layer.type == 'signal':
                conductivity = row.get('Conductivity')
                if conductivity is not None:
                    mat_name = f"cond_{int(conductivity)}"
                    if not edb.materials.materials.get(mat_name):
                        logging.info(f"Creating new conductor material: {mat_name}")
                        edb.materials.add_conductor_material(mat_name, conductivity=conductivity)
                    layer.material = mat_name
            
                # Update Etching Factor
                etch_factor = row.get('Etching Factor')
                if etch_factor is not None:
                    layer.etch_factor = etch_factor

                # Update Roughness Model
                roughness_params = {
                    'top_radius': row.get('Top Nodule Radius (um)'), 'top_ratio': row.get('Top Surface Ratio'),
                    'bottom_radius': row.get('Bottom Nodule Radius (um)'), 'bottom_ratio': row.get('Bottom Surface Ratio'),
                    'side_radius': row.get('Side Nodule Radius (um)'), 'side_ratio': row.get('Side Surface Ratio'),
                }
                has_roughness_params = any(v is not None and v != 0 for v in roughness_params.values())

                if etch_factor is not None and etch_factor != 0 and has_roughness_params:
                    logging.info(f"Enabling roughness for layer {layer_name}")
                    layer.roughness_enabled = True
                    if roughness_params['top_radius'] is not None and roughness_params['top_ratio'] is not None:
                        layer.assign_roughness_model(
                            model_type="huray",
                            huray_radius=f"{roughness_params['top_radius']}um",
                            huray_surface_ratio=str(roughness_params['top_ratio']),
                            apply_on_surface="top"
                        )
                    if roughness_params['bottom_radius'] is not None and roughness_params['bottom_ratio'] is not None:
                        layer.assign_roughness_model(
                            model_type="huray",
                            huray_radius=f"{roughness_params['bottom_radius']}um",
                            huray_surface_ratio=str(roughness_params['bottom_ratio']),
                            apply_on_surface="bottom"
                        )
                    if roughness_params['side_radius'] is not None and roughness_params['side_ratio'] is not None:
                        layer.assign_roughness_model(
                            model_type="huray",
                            huray_radius=f"{roughness_params['side_radius']}um",
                            huray_surface_ratio=str(roughness_params['side_ratio']),
                            apply_on_surface="side"
                        )
                else:
                    layer.roughness_enabled = False


        # --- Fill Material Update Loop ---
        logging.info("Updating fill materials for signal layers.")
        signal_layers = [l for l in all_layers if l.type == 'signal']
        n = len(signal_layers)
        mid_point = math.ceil(n / 2)

        for i, layer in enumerate(all_layers):
            if layer.type != 'signal':
                continue

            # Find current signal layer's index in the signal_layers list
            signal_layer_index = signal_layers.index(layer)

            if signal_layer_index < mid_point: # First half, look up
                adjacent_diel = next((l for l in reversed(all_layers[:i]) if l.type == 'dielectric'), None)
            else: # Second half, look down
                adjacent_diel = next((l for l in all_layers[i+1:] if l.type == 'dielectric'), None)
            
            if adjacent_diel and adjacent_diel.material:
                logging.info(f"Assigning fill material '{adjacent_diel.material}' to layer '{layer.name}'")
                layer.fill_material = adjacent_diel.material
            else:
                logging.warning(f"Could not find adjacent dielectric material for signal layer '{layer.name}'")

        # 4. Save the updated EDB project to the specified output path
        if os.path.exists(output_aedb_path):
             logging.warning(f"Output path {output_aedb_path} already exists. It will be overwritten.")
        edb.save_edb_as(output_aedb_path)
        logging.info(f"Successfully saved updated EDB project to: {output_aedb_path}")
        return True, "Import successful."

    except Exception as e:
        msg = f"An error occurred during the import process: {e}"
        logging.error(msg, exc_info=True)
        return False, msg
    finally:
        if edb:
            edb.close_edb()
            logging.info("EDB project closed.")


if __name__ == '__main__':
    # Define paths for standalone execution
    current_dir = os.path.dirname(os.path.abspath(__file__))
    # This test now requires a pre-existing .aedb folder.
    # You can generate one by running export_stackup_to_excel.py first.
    base_aedb_path = os.path.join(current_dir, 'Galileo_G87173_204.aedb') 
    excel_input_path = os.path.join(current_dir, 'stackup_report.xlsx')
    aedb_output_path = os.path.join(current_dir, 'updated_design_from_aedb.aedb')

    logging.info("--- Running Import Stackup Script in Standalone Mode ---")

    if not os.path.exists(excel_input_path) or not os.path.exists(base_aedb_path):
        logging.error(f"Test files not found. Ensure '{os.path.basename(excel_input_path)}' and '{os.path.basename(base_aedb_path)}' exist.")
        logging.error("Please run 'export_stackup_to_excel.py' first to generate the necessary files.")
    else:
        success = import_stackup_from_excel(
            edb_path=base_aedb_path,
            excel_path=excel_input_path,
            output_aedb_path=aedb_output_path
        )

        if success:
            logging.info("--- Import process completed successfully. ---")
        else:
            logging.error("--- Import process failed. ---")
