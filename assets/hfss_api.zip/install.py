import os
import subprocess
import sys
from pathlib import Path

def find_latest_ansys_python_from_env():
    """
    Finds the latest ANSYS EM Python executable by scanning ANSYSEM_ROOT environment variables.

    Returns:
        Path: The path to the latest python.exe found, or None.
    """
    ansys_versions = {}
    print("Scanning ANSYSEM_ROOT environment variables...")
    for var, value in os.environ.items():
        if var.startswith("ANSYSEM_ROOT"):
            try:
                version_num = int(var.replace("ANSYSEM_ROOT", ""))
                ansys_versions[version_num] = Path(value)
                print(f"Found version v{version_num} at {value}")
            except (ValueError, TypeError):
                continue

    if not ansys_versions:
        print("Error: No ANSYSEM_ROOT environment variables found.")
        return None

    latest_version = max(ansys_versions.keys())
    print(f"\nLatest version found: v{latest_version}")
    
    ansys_em_path = ansys_versions[latest_version]
    
    # The ANSYSEM_ROOT path can be .../AnsysEM or .../Win64. 
    # We need to navigate up to the version root directory (e.g., v252).
    version_root = ansys_em_path.parent
    if "win64" in ansys_em_path.name.lower():
        version_root = ansys_em_path.parent.parent

    # Now search for the Python executable within the commonfiles directory
    python_search_paths = list(version_root.glob("commonfiles/CPython/3_*/winx64/Release/python/python.exe"))
    
    if not python_search_paths:
        print(f"Error: Could not find a CPython installation within {version_root}")
        return None
        
    # In case there are multiple matches (e.g., 3_10, 3_11), sort to get the latest
    python_search_paths.sort(reverse=True)
    latest_python_exe = python_search_paths[0]
    
    print(f"Selected Python executable: {latest_python_exe}")
    return latest_python_exe

def create_venv(python_exe):
    """Creates a virtual environment in the current directory."""
    venv_path = Path(".venv")
    if venv_path.exists():
        print("\nVirtual environment '.venv' already exists. Skipping creation.")
        return True

    print(f"\nCreating virtual environment in '.venv' using {python_exe}...")
    try:
        subprocess.run([str(python_exe), "-m", "venv", ".venv"], check=True, capture_output=True, text=True)
        print("Virtual environment created successfully.")
        return True
    except subprocess.CalledProcessError as e:
        print("--- VENV CREATION FAILED ---")
        print(f"Error: {e}\nSTDOUT:\n{e.stdout}\nSTDERR:\n{e.stderr}")
        return False

def install_requirements():
    """Installs packages from requirements.txt into the .venv."""
    venv_pip = Path(".venv") / "Scripts" / "pip.exe"
    requirements_file = Path("requirements.txt")

    if not venv_pip.exists() or not requirements_file.exists():
        print("Error: pip.exe or requirements.txt not found.")
        return False

    print("\nInstalling packages from requirements.txt...")
    try:
        subprocess.run([str(venv_pip), "install", "-r", str(requirements_file)], check=True, capture_output=True, text=True)
        print("Packages installed successfully.")
        return True
    except subprocess.CalledProcessError as e:
        print("--- PACKAGE INSTALLATION FAILED ---")
        print(f"Error: {e}\nSTDOUT:\n{e.stdout}\nSTDERR:\n{e.stderr}")
        return False

if __name__ == "__main__":
    ansys_python = find_latest_ansys_python_from_env()
    
    if ansys_python:
        if create_venv(ansys_python):
            if not install_requirements():
                sys.exit(1)
    else:
        print("\nCould not proceed with virtual environment setup.")
        sys.exit(1)

    print("\nSetup complete.")
    sys.exit(0)
