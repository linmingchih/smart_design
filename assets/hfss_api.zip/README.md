# HFSS 兩步模擬自動化專案

## 描述

本專案提供了一套自動化腳本，旨在使用 Ansys HFSS API 執行一個包含兩個主要步驟的電磁模擬流程。此工具透過 Python 腳本與 HFSS 互動，實現了無需手動操作即可完成複雜模擬的高度自動化。

主要功能包括：
- 自動建立 Python 虛擬環境並安裝所需套件。
- 透過 `main.py` 腳本控制整個模擬流程。
- 使用 `hfss_api.py` 封裝與 Ansys HFSS 的通訊細節。
- 透過 `machines.json` 設定可用於分散式計算的機器資源。

---

## 先決條件

在開始之前，請確保您的系統已安裝以下軟體：
- **Ansys Electronics Desktop (AEDT)**：需要包含 HFSS 的有效授權版本。
- **Python 3.8+**：確保已將 Python 加入系統環境變數 (PATH)。

---

## 安裝指南

1.  **克隆存儲庫**
    使用 Git 克隆此專案到您的本地機器。
    ```bash
    git clone https://github.com/your-username/jack-two-steps-simulation-HFSS.git
    cd jack-two-steps-simulation-HFSS
    ```

2.  **安裝 Python 依賴包**
    直接執行 `run.bat` 批次檔。該腳本會自動處理環境設定：
    -   **首次執行**：如果 `.venv` 虛擬環境目錄不存在，腳本將會：
        1.  自動建立一個名為 `.venv` 的 Python 虛擬環境。
        2.  啟動該虛擬環境。
        3.  讀取 `requirements.txt` 檔案並使用 `pip` 安裝所有必要的 Python 套件（例如 `PySide6`, `psutil`）。
    -   **後續執行**：如果 `.venv` 已存在，腳本將跳過安裝步驟，直接使用現有的環境執行應用程式。

---

## 使用方式

直接雙擊或在命令提示字元中執行 `run.bat` 即可開始模擬。

```bash
run.bat
```

腳本執行後，將會：
1.  檢查並設定好 Python 環境。
2.  使用虛擬環境中的 Python 解譯器執行 `main.py`。
3.  `main.py` 將啟動 HFSS 應用程式（可能在背景執行），並根據腳本中定義的邏輯執行兩步模擬。
4.  所有日誌和進度將顯示在命令提示字元視窗中。
5.  模擬完成後，視窗將會顯示 `Press any key to continue...`，讓您有時間查看輸出結果，然後再手動關閉。

---

## 設定

### 計算資源設定

您可以透過編輯 `machines.json` 檔案來管理用於分散式計算的機器列表。該檔案包含一個 JSON 陣列，每個物件代表一台可用的機器及其資源。

**`machines.json` 檔案範例：**
```json
[
    {
        "name": "machine_A",
        "cores": 32,
        "ram": 64
    },
    {
        "name": "machine_B",
        "cores": 64,
        "ram": 256
    },
    {
        "name": "machine_C",
        "cores": 128,
        "ram": 256
    }
]
```
- `name`: 機器的網路名稱或 IP 位址。
- `cores`: 可用的 CPU 核心數。
- `ram`: 可用的記憶體大小 (GB)。

---

## 專案結構

以下是主要檔案的功能說明：

-   `run.bat`: **(啟動腳本)**
    使用者執行的主要入口點。負責環境檢查、依賴包安裝和啟動 Python 應用程式。

-   `main.py`: **(主要應用程式邏輯)**
    包含模擬流程的核心邏輯。它會匯入並使用 `hfss_api` 來執行具體的 HFSS 操作，並完成兩步模擬的流程。

-   `hfss_api.py`: **(HFSS API 封裝)**
    一個模組，用於封裝與 Ansys HFSS 軟體互動的底層 API 呼叫，提供更簡潔、高階的介面給 `main.py` 使用。

-   `requirements.txt`: **(Python 依賴包)**
    定義了專案所需的 Python 套件列表。

-   `machines.json`: **(機器設定檔)**
    定義了可用於模擬的計算資源。

-   `.gitignore`: **(Git 忽略設定)**
    設定 Git 應忽略的檔案和目錄，例如 `.venv` 和 `__pycache__`。

---

## 授權

本專案採用 MIT 授權。