import sys
import os

def find_ansys_versions():
    """
    Finds installed ANSYS EM versions from environment variables.
    Returns a dictionary mapping a display name (e.g., 'v241') to the root installation path.
    """
    versions = {}
    for var, path in os.environ.items():
        if var.startswith("ANSYSEM_ROOT"):
            # Extract version number like "241" from "ANSYSEM_ROOT241"
            version_key = f"v{var.replace('ANSYSEM_ROOT', '')}"
            if os.path.exists(os.path.join(path, 'ansysedt.exe')):
                versions[version_key] = path
    return versions

def get_project_data(version_path, project_path):
    """
    Initializes a non-graphical HFSS session to extract all design, setup,
    and sweep information from a given .aedt project.

    Args:
        version_path (str): The root path of the ANSYS EM installation.
        project_path (str): The absolute path to the .aedt file.

    Returns:
        A dictionary containing the project data, or None if an error occurs.
        Example: {'Design1': {'Setup1': ['Sweep1', 'Sweep2']}}
    """
    api_path = os.path.join(version_path, "PythonFiles", "DesktopPlugin")
    if api_path not in sys.path:
        sys.path.append(api_path)

    project_data = {}
    oDesktop = None
    try:
        import ScriptEnv
        print(f"Attempting to initialize HFSS API from: {api_path}")
        ScriptEnv.InitializeNew(NonGraphical=True)
        print("HFSS API InitializeNew() called.")

        # After initialization, oDesktop should be injected.
        # Let's try to find it, checking the current module's globals first.
        if "oDesktop" in globals():
            print("Found oDesktop in hfss_api module globals.")
            oDesktop = globals()["oDesktop"]
        elif "oDesktop" in sys.modules["__main__"].__dict__:
            print("Found oDesktop in __main__ module globals.")
            oDesktop = sys.modules["__main__"].oDesktop
        else:
            raise Exception("oDesktop object not found after HFSS API initialization.")

        print(f"Successfully initialized oDesktop. Opening project: {project_path}")
        oProject = oDesktop.OpenProject(project_path)
        print(f"Successfully opened project.")
        
        design_list = oProject.GetTopDesignList()
        print(f"Found designs: {design_list}")
        for design_name in design_list:
            project_data[design_name] = {}
            oDesign = oProject.SetActiveDesign(design_name)
            oModule = oDesign.GetModule('AnalysisSetup')
            setups = oModule.GetSetups()
            for setup_name in setups:
                sweeps = oModule.GetSweeps(setup_name)
                project_data[design_name][setup_name] = list(sweeps)
        
        oProject.Close()
        print("Project data extracted and project closed.")
        return project_data
    except Exception as e:
        print(f"HFSS API Error: {e}")
        return None
    finally:
        if oDesktop:
            try:
                import ScriptEnv
                ScriptEnv.Shutdown()
                print("HFSS API Shutdown() called.")
            except Exception as e:
                print(f"HFSS API Shutdown Error: {e}")
        # Clean up the path
        if api_path in sys.path:
            sys.path.remove(api_path)


def set_sweeps_enabled(version_path, project_path, design_name, setup_name, enabled=True):
    """
    Initializes a non-graphical HFSS session to enable or disable all sweeps
    for a specific setup in a design.

    Args:
        version_path (str): The root path of the ANSYS EM installation.
        project_path (str): The absolute path to the .aedt file.
        design_name (str): The name of the design to modify.
        setup_name (str): The name of the setup containing the sweeps.
        enabled (bool): True to enable all sweeps, False to disable them.

    Returns:
        True if successful, False otherwise.
    """
    api_path = os.path.join(version_path, "PythonFiles", "DesktopPlugin")
    if api_path not in sys.path:
        sys.path.append(api_path)

    oDesktop = None
    action = "Enabling" if enabled else "Disabling"
    try:
        import ScriptEnv
        print(f"Attempting to initialize HFSS API from: {api_path}")
        ScriptEnv.InitializeNew(NonGraphical=True)
        print("HFSS API InitializeNew() called.")

        if "oDesktop" in globals():
            oDesktop = globals()["oDesktop"]
        elif "oDesktop" in sys.modules["__main__"].__dict__:
            oDesktop = sys.modules["__main__"].oDesktop
        else:
            raise Exception("oDesktop object not found after HFSS API initialization.")

        print(f"Successfully initialized oDesktop. Opening project: {project_path}")
        oProject = oDesktop.OpenProject(project_path)
        print(f"Successfully opened project.")
        
        oDesign = oProject.SetActiveDesign(design_name)
        oModule = oDesign.GetModule('AnalysisSetup')
        sweeps = oModule.GetSweeps(setup_name)
        
        print(f"{action} {len(sweeps)} sweeps in {design_name}/{setup_name}...")
        for sweep_name in sweeps:
            # The path to the sweep object in the project tree
            sweep_path = f'{design_name}/Analysis/{setup_name}/{sweep_name}'
            oProject.GetChildObject(sweep_path).Enabled = enabled
            print(f"  - Sweep '{sweep_name}' Enabled set to {enabled}")

        oProject.Save()
        oProject.Close()
        print(f"Successfully finished {action.lower()} sweeps. Project saved and closed.")
        return True
    except Exception as e:
        print(f"HFSS API Error during sweep modification: {e}")
        return False
    finally:
        if oDesktop:
            try:
                import ScriptEnv
                ScriptEnv.Shutdown()
                print("HFSS API Shutdown() called.")
            except Exception as e:
                print(f"HFSS API Shutdown Error: {e}")
        # Clean up the path
        if api_path in sys.path:
            sys.path.remove(api_path)
