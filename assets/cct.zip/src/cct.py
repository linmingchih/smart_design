import json
import os
import re
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

try:  # pragma: no cover - optional dependency
    from ansys.aedt.core import Circuit
    from ansys.aedt.core.generic.constants import Setups
except ImportError:  # pragma: no cover - allow metadata utilities without AEDT
    Circuit = None
    Setups = None

ROOT_DIR = Path(__file__).resolve().parents[1]
NETLIST_DEBUG_DIR = ROOT_DIR / "data" / "netlist"
import numpy as np

def integrate_nonuniform(x_list, y_list):
    integral = 0.0
    for i in range(len(x_list) - 1):
        dx = x_list[i + 1] - x_list[i]
        integral += 0.5 * (y_list[i] + y_list[i + 1]) * dx
    return integral


def get_sig_isi(time_list, voltage_list, unit_interval):
    """Compute signal and ISI metrics over the provided waveform."""
    t = np.asarray(time_list, dtype=float)
    v = np.asarray(voltage_list, dtype=float)
    if t.ndim != 1 or v.ndim != 1 or t.size != v.size:
        raise ValueError("time_list and voltage_list must be 1-D and of equal length")
    if unit_interval <= 0:
        raise ValueError("unit_interval must be positive")

    order = np.argsort(t)
    t = t[order]
    v = v[order]

    if t[-1] - t[0] < unit_interval:
        raise ValueError("Waveform duration is shorter than unit interval")

    dt = np.diff(t)
    trap = np.concatenate([[0.0], np.cumsum((v[:-1] + v[1:]) * 0.5 * dt)])
    trap_abs = np.concatenate([[0.0], np.cumsum((np.abs(v[:-1]) + np.abs(v[1:])) * 0.5 * dt)])
    total_abs = trap_abs[-1]

    n = len(t)
    last_i = np.searchsorted(t, t[-1] - unit_interval, side="right") - 1
    if last_i < 0:
        raise ValueError("No valid integration window of length unit_interval")

    sig_max = -np.inf
    best_i = best_j = 0
    best_t_end = None
    j = 0

    for i in range(last_i + 1):
        t_end = t[i] + unit_interval
        while j + 1 < n and t[j + 1] <= t_end:
            j += 1

        integ = trap[j] - trap[i]
        if j + 1 < n and t[j] < t_end < t[j + 1]:
            v_end = v[j] + (v[j + 1] - v[j]) * (t_end - t[j]) / (t[j + 1] - t[j])
            integ += 0.5 * (v[j] + v_end) * (t_end - t[j])

        if integ > sig_max:
            sig_max = integ
            best_i, best_j, best_t_end = i, j, t_end

    i, j, t_end = best_i, best_j, best_t_end
    integ_abs = trap_abs[j] - trap_abs[i]
    if j + 1 < n and t[j] < t_end < t[j + 1]:
        v_end = v[j] + (v[j + 1] - v[j]) * (t_end - t[j]) / (t[j + 1] - t[j])
        integ_abs += 0.5 * (abs(v[j]) + abs(v_end)) * (t_end - t[j])

    sig = float(sig_max)
    isi = float(total_abs - integ_abs)
    return sig, isi


@dataclass
class PortMetadata:
    sequence: int
    name: str
    component: str
    component_role: str
    net: str
    net_type: str
    pair: Optional[str] = None
    polarity: Optional[str] = None


def _normalize_role(value: Optional[str]) -> str:
    if not value:
        return "unknown"
    value = str(value).lower()
    if value in {"controller", "ctrl", "host"}:
        return "controller"
    if value in {"dram", "memory", "mem"}:
        return "dram"
    return value


def _normalize_net_type(value: Optional[str]) -> str:
    if not value:
        return "single"
    value = str(value).lower()
    if value in {"diff", "differential"}:
        return "differential"
    return "single"


def _normalize_polarity(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    value = str(value).lower()
    if value in {"positive", "pos", "+", "p"}:
        return "positive"
    if value in {"negative", "neg", "-", "n"}:
        return "negative"
    return value

def prefix_port_name(name: str, sequence: int) -> str:
    base = str(name or '')
    match = re.match(r'^\d+_(.*)$', base)
    if match:
        base = match.group(1)
    base = base.strip()
    return f"{sequence}_{base}" if base else str(sequence)


def load_port_metadata(path: str | Path) -> Tuple[List[PortMetadata], Dict[str, object]]:
    meta_path = Path(path)
    with meta_path.open("r", encoding="utf-8") as handle:
        raw: Dict[str, object] = json.load(handle)

    entries: List[PortMetadata] = []
    for index, item in enumerate(raw.get("ports", []), 1):
        entries.append(
            PortMetadata(
                sequence=int(item.get("sequence", index)),
                name=str(item.get("name", "")),
                component=str(item.get("component", "")),
                component_role=_normalize_role(item.get("component_role")),
                net=str(item.get("net", "")),
                net_type=_normalize_net_type(item.get("net_type")),
                pair=item.get("pair"),
                polarity=_normalize_polarity(item.get("polarity")),
            )
        )

    if not entries:
        raise ValueError(f"No ports found in metadata file: {meta_path}")

    entries.sort(key=lambda entry: entry.sequence)
    for idx, entry in enumerate(entries, 1):
        entry.sequence = idx
        entry.name = prefix_port_name(entry.name, idx)

    return entries, raw


class Tx:
    def __init__(self, meta: PortMetadata, vhigh, t_rise, ui, res_tx, cap_tx):
        self.meta = meta
        self.pid = meta.sequence
        self.sequence = meta.sequence
        self.label = meta.name
        self.active = [
            f"V{self.pid} netb_{self.pid} 0 PULSE(0 {vhigh} 1e-10 {t_rise} {t_rise} {ui} 1.5e+100)",
            f"R{self.pid} netb_{self.pid} net_{self.pid} {res_tx}",
            f"C{self.pid} netb_{self.pid} 0 {cap_tx}",
        ]
        self.passive = [
            f"R{self.pid} netb_{self.pid} net_{self.pid} {res_tx}",
            f"C{self.pid} netb_{self.pid} 0 {cap_tx}",
        ]

    def get_netlist(self, active: bool = True) -> List[str]:
        return self.active if active else self.passive


class Tx_diff:
    def __init__(
        self,
        positive: PortMetadata,
        negative: PortMetadata,
        vhigh,
        t_rise,
        ui,
        res_tx,
        cap_tx,
    ) -> None:
        self.pos = positive
        self.neg = negative
        self.pid_pos = positive.sequence
        self.pid_neg = negative.sequence
        self.sequence = min(positive.sequence, negative.sequence)
        self.label = positive.pair or f"{positive.name}/{negative.name}"
        self.active = [
            f"V{self.pid_pos} netb_{self.pid_pos} 0 PULSE(0 {vhigh} 1e-10 {t_rise} {t_rise} {ui} 1.5e+100)",
            f"R{self.pid_pos} netb_{self.pid_pos} net_{self.pid_pos} {res_tx}",
            f"C{self.pid_pos} netb_{self.pid_pos} 0 {cap_tx}",
            f"V{self.pid_neg} netb_{self.pid_neg} 0 PULSE(0 -{vhigh} 1e-10 {t_rise} {t_rise} {ui} 1.5e+100)",
            f"R{self.pid_neg} netb_{self.pid_neg} net_{self.pid_neg} {res_tx}",
            f"C{self.pid_neg} netb_{self.pid_neg} 0 {cap_tx}",
        ]
        self.passive = [
            f"R{self.pid_pos} netb_{self.pid_pos} net_{self.pid_pos} {res_tx}",
            f"C{self.pid_pos} netb_{self.pid_pos} 0 {cap_tx}",
            f"R{self.pid_neg} netb_{self.pid_neg} net_{self.pid_neg} {res_tx}",
            f"C{self.pid_neg} netb_{self.pid_neg} 0 {cap_tx}",
        ]

    def get_netlist(self, active: bool = True) -> List[str]:
        return self.active if active else self.passive


class Rx:
    def __init__(self, meta: PortMetadata, res_rx, cap_rx):
        self.meta = meta
        self.pid = meta.sequence
        self.sequence = meta.sequence
        self.label = meta.name
        self.netlist = [
            f"R{self.pid} net_{self.pid} 0 {res_rx}",
            f"C{self.pid} net_{self.pid} 0 {cap_rx}",
        ]
        self.waveforms: Dict[object, Tuple[List[float], List[float]]] = {}
        self.expected_tx: Optional[object] = None

    def get_netlist(self) -> List[str]:
        return self.netlist


class Rx_diff:
    def __init__(self, positive: PortMetadata, negative: PortMetadata, res_rx, cap_rx):
        self.pos = positive
        self.neg = negative
        self.pid_pos = positive.sequence
        self.pid_neg = negative.sequence
        self.label = positive.pair or f"{positive.name}/{negative.name}"
        self.netlist = [
            f"R{self.pid_pos} net_{self.pid_pos} 0 {res_rx}",
            f"C{self.pid_pos} net_{self.pid_pos} 0 {cap_rx}",
            f"R{self.pid_neg} net_{self.pid_neg} 0 {res_rx}",
            f"C{self.pid_neg} net_{self.pid_neg} 0 {cap_rx}",
        ]
        self.waveforms: Dict[object, Tuple[List[float], List[float]]] = {}
        self.expected_tx: Optional[object] = None

    def get_netlist(self) -> List[str]:
        return self.netlist


class Design:
    def __init__(self, workdir: Path, tstep='100ps', tstop='3ns'):
        if Circuit is None or Setups is None:
            raise ImportError("ansys.aedt.core is required to run CCT simulations")

        self.workdir = Path(workdir)
        self.workdir.mkdir(parents=True, exist_ok=True)

        self.netlist_path = self.workdir / f"{uuid.uuid4()}.cir"
        self.netlist_path.write_text('', encoding='utf-8')

        self.circuit = circuit = Circuit(
            version='2025.1',
            non_graphical=True,
            close_on_exit=True,
        )

        circuit.add_netlist_datablock(str(self.netlist_path))
        self.setup = circuit.create_setup('myTransient', Setups.NexximTransient)
        self.setup.props['TransientData'] = [tstep, tstop]
        self.circuit.save_project()

    def run(self, netlist):
        with open(self.netlist_path, 'w') as f:
            f.write(netlist)

        self.circuit.odesign.InvalidateSolution('myTransient')
        self.circuit.save_project()
        self.circuit.analyze('myTransient')
        self.circuit.save_project()

        result = {}
        for v in self.circuit.post.available_report_quantities():
            data = self.circuit.post.get_solution_data(v, domain='Time')
            x = [1e3 * i for i in data.primary_sweep_values]
            y = [1e-3 * i for i in data.data_real()]
            m = re.search(r'net_(\d+)', v)
            if m:
                number = int(m.group(1))
                result[number] = (x, y)
        return result


class CCT:
    def __init__(
        self,
        snp_path: str | Path,
        port_metadata_path: str | Path,
        workdir: Optional[str | Path] = None,
    ):
        self.snp_path = str(snp_path)
        self.port_metadata, self.metadata_info = load_port_metadata(port_metadata_path)
        self.reference_net = self.metadata_info.get("reference_net")
        self.controller_components = self.metadata_info.get("controller_components", [])
        self.dram_components = self.metadata_info.get("dram_components", [])

        metadata_dir = Path(port_metadata_path).resolve().parent
        if workdir is None:
            workdir = metadata_dir / "cct_work"
        self.workdir = Path(workdir)
        self.workdir.mkdir(parents=True, exist_ok=True)

        self.output_dir = metadata_dir
        NETLIST_DEBUG_DIR.mkdir(parents=True, exist_ok=True)

        self.txs: List[object] = []
        self.rxs: List[object] = []

        self._classify_ports()

        nets = ' '.join([f'net_{entry.sequence}' for entry in self.port_metadata])
        self.netlist = [
            f'.model "Channel" S TSTONEFILE="{self.snp_path}" INTERPOLATION=LINEAR INTDATTYP=MA HIGHPASS=10 LOWPASS=10 convolution=1 enforce_passivity=0 Noisemodel=External',
            f'S1 {nets} FQMODEL="Channel"',
        ]

    def _classify_ports(self) -> None:
        self.tx_single_entries = [
            entry for entry in self.port_metadata if entry.component_role == "controller" and entry.net_type == "single"
        ]
        self.rx_single_entries = [
            entry for entry in self.port_metadata if entry.component_role == "dram" and entry.net_type == "single"
        ]
        self.tx_diff_entries = self._group_differential("controller")
        self.rx_diff_entries = self._group_differential("dram")

        self.tx_single_map: Dict[str, Tx] = {}
        self.tx_diff_map: Dict[str, Tx_diff] = {}

    def _group_differential(self, role: str) -> List[Tuple[PortMetadata, PortMetadata]]:
        groups: Dict[Tuple[str, str], Dict[str, PortMetadata]] = {}
        for entry in self.port_metadata:
            if entry.component_role != role or entry.net_type != "differential":
                continue
            key = (entry.component, entry.pair or entry.net)
            suggested = "positive" if "positive" not in groups.get(key, {}) else "negative"
            polarity = entry.polarity or suggested
            groups.setdefault(key, {})[polarity] = entry

        pairs: List[Tuple[PortMetadata, PortMetadata]] = []
        for (_component, _pair_name), mapping in groups.items():
            pos = mapping.get("positive")
            neg = mapping.get("negative")
            if not pos or not neg:
                continue
            pairs.append((pos, neg))

        pairs.sort(key=lambda item: min(item[0].sequence, item[1].sequence))
        return pairs

    @staticmethod
    def _diff_identifier(positive: PortMetadata, negative: PortMetadata) -> Tuple[str, str]:
        return tuple(sorted([positive.net, negative.net]))

    def set_txs(self, vhigh, t_rise, ui, res_tx, cap_tx):
        self.ui = ui
        self.txs = []
        self.tx_single_map = {}
        self.tx_diff_map = {}
        for entry in self.tx_single_entries:
            tx = Tx(entry, vhigh, t_rise, ui, res_tx, cap_tx)
            self.txs.append(tx)
            self.tx_single_map[entry.net] = tx
        for pos_entry, neg_entry in self.tx_diff_entries:
            txd = Tx_diff(pos_entry, neg_entry, vhigh, t_rise, ui, res_tx, cap_tx)
            self.txs.append(txd)
            identifier = self._diff_identifier(pos_entry, neg_entry)
            self.tx_diff_map[identifier] = txd

    def set_rxs(self, res_rx, cap_rx):
        self.rxs = []
        for entry in self.rx_single_entries:
            rx = Rx(entry, res_rx, cap_rx)
            rx.expected_tx = self.tx_single_map.get(entry.net)
            self.rxs.append(rx)
        for pos_entry, neg_entry in self.rx_diff_entries:
            rx = Rx_diff(pos_entry, neg_entry, res_rx, cap_rx)
            identifier = self._diff_identifier(pos_entry, neg_entry)
            rx.expected_tx = self.tx_diff_map.get(identifier)
            self.rxs.append(rx)

    def run(self, tstep='100ps', tstop='3ns'):
        design = Design(self.workdir, tstep, tstop)
        for tx1 in self.txs:
            netlist = [i for i in self.netlist]
            for tx2 in self.txs:
                if tx2 == tx1:
                    netlist += tx2.get_netlist(True)
                else:
                    netlist += tx2.get_netlist(False)

            for rx in self.rxs:
                netlist += rx.get_netlist()

            netlist_text = '\n'.join(netlist)
            self._write_debug_netlist(tx1, netlist_text)
            result = design.run(netlist_text)

            for rx in self.rxs:
                if isinstance(rx, Rx):
                    if rx.sequence in result:
                        rx.waveforms[tx1] = result[rx.sequence]
                elif isinstance(rx, Rx_diff):
                    if rx.pid_pos not in result or rx.pid_neg not in result:
                        continue
                    time_pos, waveform_pos = result[rx.pid_pos]
                    _, waveform_neg = result[rx.pid_neg]
                    new_result = (time_pos, [vpos - vneg for vpos, vneg in zip(waveform_pos, waveform_neg)])
                    rx.waveforms[tx1] = new_result

    def calculate(self, output_path):
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)

        ui = float(self.ui.replace('ps', ''))

        result = []
        for rx in self.rxs:
            if not getattr(rx, 'waveforms', None):
                continue
            primary_tx = getattr(rx, 'expected_tx', None)
            if primary_tx is None:
                continue
            waveform_primary = rx.waveforms.get(primary_tx)
            if waveform_primary is None:
                continue
            sig = isi = 0.0
            xtalk = 0.0
            for tx, waveform in rx.waveforms.items():
                time, voltage = waveform
                if tx == primary_tx:
                    sig, isi = get_sig_isi(time, voltage, ui)
                else:
                    xtalk += integrate_nonuniform(time, [abs(v) for v in voltage])
            pseudo_eye = sig - isi - xtalk
            denom = isi + xtalk
            p_ratio = sig / denom if denom else float('inf')

            tx_label = getattr(primary_tx, 'label', getattr(primary_tx, 'pid', 'unknown'))
            rx_label = getattr(rx, 'label', str(getattr(rx, 'pid', 'unknown')))
            result.append(
                f'{tx_label}, {rx_label}, {sig:.3f}, {isi:.3f}, {xtalk:.3f}, {pseudo_eye:.3f}, {p_ratio:.3f}'
            )

        with output_file.open('w') as f:
            f.writelines('tx_name, rx_name, sig(V*ps), isi(V*ps), xtalk(V*ps), pseudo_eye(V*ps), power_ratio\n')
            f.write('\n'.join(result))

    def _write_debug_netlist(self, tx_obj: object, netlist_text: str) -> None:
        if not netlist_text:
            return
        sequence = getattr(tx_obj, 'sequence', None)
        label = getattr(tx_obj, 'label', f"tx_{sequence if sequence is not None else 'unknown'}")
        sanitized = re.sub(r'[^A-Za-z0-9_.-]+', '_', label).strip('_') or 'tx'
        if sequence is not None:
            filename = f"netlist_{sequence:03d}_{sanitized}.cir"
        else:
            filename = f"netlist_{sanitized}.cir"
        path = NETLIST_DEBUG_DIR / filename
        path.write_text(netlist_text, encoding='utf-8')

if __name__ == '__main__':
    import sys

    if len(sys.argv) >= 3:
        touchstone_path = sys.argv[1]
        metadata_path = sys.argv[2]
        output_csv = sys.argv[3] if len(sys.argv) >= 4 else str(Path(metadata_path).with_name(f"{Path(metadata_path).stem}_cct.csv"))
    else:
        touchstone_path = r"D:\OneDrive - ANSYS, Inc\a-client-repositories\quanta-cct-circuit-202508\data\Sweep1_DV3.s88p"
        metadata_path = r"D:\OneDrive - ANSYS, Inc\a-client-repositories\quanta-cct-circuit-202508\output\Sweep1_DV3_ports.json"
        output_csv = str(Path(metadata_path).with_name(f"{Path(metadata_path).stem}_cct.csv"))

    cct = CCT(touchstone_path, metadata_path)
    cct.set_txs(vhigh="0.8V", t_rise="30ps", ui="133ps", res_tx="40ohm", cap_tx="1pF")
    cct.set_rxs(res_rx="30ohm", cap_rx="1.8pF")
    cct.run()
    cct.calculate(output_path=output_csv)
