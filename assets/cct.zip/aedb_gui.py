import json
import json
import re
import sys
import traceback
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

try:
    from PySide6.QtCore import Qt, QSettings
    from PySide6.QtGui import QColor, QBrush
    from PySide6.QtWidgets import (
        QApplication,
        QFileDialog,
        QGroupBox,
        QHBoxLayout,
        QLabel,
        QListWidget,
        QListWidgetItem,
        QMessageBox,
        QPushButton,
        QFormLayout,
        QDoubleSpinBox,
        QVBoxLayout,
        QWidget,
        QAbstractItemView,
        QComboBox,
        QTabWidget,
        QLineEdit,
        QTableWidget,
        QTableWidgetItem,
        QHeaderView,
        QProgressBar,
    )
    QT_LIB = "PySide6"
except ImportError:  # pragma: no cover - fallback when PySide6 is unavailable
    from PySide2.QtCore import Qt, QSettings
    from PySide2.QtGui import QColor, QBrush
    from PySide2.QtWidgets import (
        QApplication,
        QFileDialog,
        QGroupBox,
        QHBoxLayout,
        QLabel,
        QListWidget,
        QListWidgetItem,
        QMessageBox,
        QPushButton,
        QFormLayout,
        QDoubleSpinBox,
        QVBoxLayout,
        QWidget,
        QAbstractItemView,
        QComboBox,
        QTabWidget,
        QLineEdit,
        QTableWidget,
        QTableWidgetItem,
        QHeaderView,
        QProgressBar,
    )
    QT_LIB = "PySide2"

from pyedb import Edb

ROOT_DIR = Path(__file__).resolve().parent
SRC_DIR = ROOT_DIR / "src"
if SRC_DIR.exists():
    src_str = str(SRC_DIR)
    if src_str not in sys.path:
        sys.path.append(src_str)

try:  # pragma: no cover - optional dependency at runtime
    from cct import CCT, load_port_metadata, prefix_port_name
except ImportError:  # pragma: no cover - allow GUI without CCT backend
    CCT = None
    load_port_metadata = None

    def prefix_port_name(name: str, sequence: int) -> str:
        base = str(name or '')
        match = re.match(r'^\d+_(.*)$', base)
        if match:
            base = match.group(1)
        base = base.strip()
        return f"{sequence}_{base}" if base else str(sequence)

_COMPONENT_PATTERN = re.compile(r"^U\d+", re.IGNORECASE)

try:
    DIFF_ROW_BRUSH = QBrush(QColor(230, 240, 255))
except NameError:  # pragma: no cover - Qt import failed
    DIFF_ROW_BRUSH = None

SETTINGS_ORG = "Ansys"
SETTINGS_APP = "AEDBNetExplorer"

DEFAULT_CCT_SETTINGS: Dict[str, float] = {
    "vhigh": 0.8,
    "t_rise": 30.0,
    "ui": 133.0,
    "res_tx": 40.0,
    "cap_tx": 1.0,
    "res_rx": 30.0,
    "cap_rx": 1.8,
    "tstep": 100.0,
    "tstop": 3.0,
}

CCT_PARAM_GROUPS = {
    "tx": ["vhigh", "t_rise", "ui", "res_tx", "cap_tx"],
    "rx": ["res_rx", "cap_rx"],
    "transient": ["tstep", "tstop"],
}


class CheckableListWidget(QListWidget):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.setSelectionBehavior(QAbstractItemView.SelectItems)
        try:
            self.setSelectionRectVisible(True)
        except AttributeError:
            pass

    def keyPressEvent(self, event) -> None:  # noqa: D401 - Qt signature
        if event.key() == Qt.Key_Space:
            items = self.selectedItems()
            if not items:
                current = self.currentItem()
                if current is not None:
                    items = [current]
            if items:
                for item in items:
                    if item.checkState() == Qt.Checked:
                        item.setCheckState(Qt.Unchecked)
                    else:
                        item.setCheckState(Qt.Checked)
            event.accept()
            return
        super().keyPressEvent(event)


class EdbGui(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("AEDB CCT Calculator")
        self.resize(1000, 650)

        self._edb: Edb | None = None
        self._components: Dict[str, object] = {}
        self._component_nets: Dict[str, set[str]] = {}
        self._aedb_path: Optional[Path] = None
        self._aedb_source_path: Optional[Path] = None
        self._edb_version: str = "2024.1"
        self._cct_metadata: Optional[dict] = None
        self._cct_port_entries: List[dict] = []
        self._settings = QSettings(SETTINGS_ORG, SETTINGS_APP)
        self._cct_param_spins: Dict[str, QDoubleSpinBox] = {}

        self._build_ui()
        self._restore_cct_settings()

    def _build_ui(self) -> None:
        main_layout = QVBoxLayout(self)

        header_layout = QHBoxLayout()
        self.open_button = QPushButton("Open .aedb?")
        self.open_button.clicked.connect(self._prompt_for_aedb)
        header_layout.addWidget(self.open_button)

        self.file_label = QLabel("No design loaded")
        self.file_label.setMinimumWidth(400)
        header_layout.addWidget(self.file_label, stretch=1)
        main_layout.addLayout(header_layout)

        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs, stretch=1)

        port_tab = QWidget()
        self._build_port_tab(port_tab)
        self.tabs.addTab(port_tab, "Port Setup")

        cct_tab = QWidget()
        self._build_cct_tab(cct_tab)
        self.tabs.addTab(cct_tab, "CCT")

        self.status_label = QLabel("")
        main_layout.addWidget(self.status_label)

    def _build_port_tab(self, container: QWidget) -> None:
        layout = QVBoxLayout(container)

        selector_layout = QHBoxLayout()

        self.controller_group = QGroupBox("Controller Components")
        controller_layout = QVBoxLayout(self.controller_group)
        self.controller_list = QListWidget()
        self.controller_list.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.controller_list.itemSelectionChanged.connect(self._update_results)
        controller_layout.addWidget(self.controller_list)

        self.dram_group = QGroupBox("DRAM Components")
        dram_layout = QVBoxLayout(self.dram_group)
        self.dram_list = QListWidget()
        self.dram_list.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.dram_list.itemSelectionChanged.connect(self._update_results)
        dram_layout.addWidget(self.dram_list)

        selector_layout.addWidget(self.controller_group, stretch=1)
        selector_layout.addWidget(self.dram_group, stretch=1)
        layout.addLayout(selector_layout)

        reference_layout = QHBoxLayout()
        reference_layout.addWidget(QLabel("Reference net:"))
        self.reference_combo = QComboBox()
        self.reference_combo.setEnabled(False)
        self.reference_combo.setFixedWidth(220)
        self.reference_combo.addItem("Select reference net...")
        reference_layout.addWidget(self.reference_combo)

        reference_layout.addStretch(1)
        self.port_count_label = QLabel("Checked nets: 0 | Ports: 0")
        self.port_count_label.setMinimumWidth(200)
        self.port_count_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        reference_layout.addWidget(self.port_count_label)
        layout.addLayout(reference_layout)

        nets_layout = QHBoxLayout()

        self.single_group = QGroupBox("Single-Ended Nets")
        single_layout = QVBoxLayout(self.single_group)
        self.single_list = CheckableListWidget()
        self.single_list.itemChanged.connect(self._update_action_state)
        single_layout.addWidget(self.single_list)
        nets_layout.addWidget(self.single_group, stretch=1)

        self.diff_group = QGroupBox("Differential Pairs")
        diff_layout = QVBoxLayout(self.diff_group)
        self.diff_list = CheckableListWidget()
        self.diff_list.itemChanged.connect(self._update_action_state)
        diff_layout.addWidget(self.diff_list)
        nets_layout.addWidget(self.diff_group, stretch=1)

        layout.addLayout(nets_layout, stretch=1)

        actions_layout = QHBoxLayout()
        actions_layout.addStretch(1)
        self.apply_button = QPushButton("Apply")
        self.apply_button.setEnabled(False)
        self.apply_button.clicked.connect(self._apply_changes)
        actions_layout.addWidget(self.apply_button)
        layout.addLayout(actions_layout)

        self.reference_combo.currentIndexChanged.connect(self._update_action_state)

    def _build_cct_tab(self, container: QWidget) -> None:
        layout = QVBoxLayout(container)

        file_layout = QVBoxLayout()

        touchstone_layout = QHBoxLayout()
        touchstone_layout.addWidget(QLabel("Touchstone (.sNp):"))
        self.cct_touchstone_edit = QLineEdit()
        self.cct_touchstone_edit.textChanged.connect(self._update_cct_ui_state)
        touchstone_layout.addWidget(self.cct_touchstone_edit, stretch=1)
        browse_touchstone = QPushButton("Browse")
        browse_touchstone.clicked.connect(self._browse_touchstone)
        touchstone_layout.addWidget(browse_touchstone)
        file_layout.addLayout(touchstone_layout)

        json_layout = QHBoxLayout()
        json_layout.addWidget(QLabel("Port metadata (.json):"))
        self.cct_json_edit = QLineEdit()
        self.cct_json_edit.textChanged.connect(self._update_cct_ui_state)
        json_layout.addWidget(self.cct_json_edit, stretch=1)
        browse_json = QPushButton("Browse")
        browse_json.clicked.connect(self._browse_metadata)
        json_layout.addWidget(browse_json)
        file_layout.addLayout(json_layout)

        layout.addLayout(file_layout)

        params_row = QHBoxLayout()

        def _make_group(title: str) -> QFormLayout:
            group = QGroupBox(title)
            form = QFormLayout(group)
            params_row.addWidget(group)
            return form

        tx_form = _make_group("TX Settings")
        rx_form = _make_group("RX Settings")
        transient_form = _make_group("Transient Settings")

        def _add_param(
            target_form: QFormLayout,
            name: str,
            label: str,
            suffix: str,
            minimum: float,
            maximum: float,
            step: float,
            decimals: int,
        ) -> None:
            spin = QDoubleSpinBox()
            spin.setRange(minimum, maximum)
            spin.setDecimals(decimals)
            spin.setSingleStep(step)
            if suffix:
                spin.setSuffix(f" {suffix}")
            default_value = DEFAULT_CCT_SETTINGS.get(name, 0.0)
            spin.setValue(default_value)
            spin.valueChanged.connect(self._persist_cct_settings)
            target_form.addRow(label, spin)
            self._cct_param_spins[name] = spin

        _add_param(tx_form, "vhigh", "TX Vhigh", "V", 0.0, 10.0, 0.05, 3)
        _add_param(tx_form, "t_rise", "TX Rise Time", "ps", 0.0, 5000.0, 1.0, 3)
        _add_param(tx_form, "ui", "Unit Interval", "ps", 0.0, 5000.0, 1.0, 3)
        _add_param(tx_form, "res_tx", "TX Resistance", "ohm", 0.0, 1000.0, 1.0, 3)
        _add_param(tx_form, "cap_tx", "TX Capacitance", "pF", 0.0, 100.0, 0.1, 3)

        _add_param(rx_form, "res_rx", "RX Resistance", "ohm", 0.0, 1000.0, 1.0, 3)
        _add_param(rx_form, "cap_rx", "RX Capacitance", "pF", 0.0, 100.0, 0.1, 3)

        _add_param(transient_form, "tstep", "Transient Step", "ps", 0.0, 1_000_000.0, 10.0, 3)
        _add_param(transient_form, "tstop", "Transient Stop", "ns", 0.0, 1_000_000.0, 0.1, 3)

        params_row.addStretch(1)

        button_container = QWidget()
        button_column = QVBoxLayout(button_container)
        button_column.setContentsMargins(0, 0, 0, 0)
        button_column.addStretch(1)
        self.cct_save_button = QPushButton("Save Config")
        self.cct_save_button.clicked.connect(self._save_cct_config)
        button_column.addWidget(self.cct_save_button)
        self.cct_load_button = QPushButton("Load Config")
        self.cct_load_button.clicked.connect(self._load_cct_config)
        button_column.addWidget(self.cct_load_button)
        self.cct_reset_button = QPushButton("Reset Defaults")
        self.cct_reset_button.clicked.connect(self._reset_cct_config)
        button_column.addWidget(self.cct_reset_button)

        params_row.addWidget(button_container, alignment=Qt.AlignBottom | Qt.AlignRight)
        layout.addLayout(params_row)

        self.cct_table = QTableWidget(0, 4)
        self.cct_table.setHorizontalHeaderLabels(["TX Port", "RX Port", "Type", "Pair"])
        header = self.cct_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Stretch)
        header.setSectionResizeMode(1, QHeaderView.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        layout.addWidget(self.cct_table, stretch=1)

        cct_actions = QHBoxLayout()
        cct_actions.addStretch(1)
        self.cct_calculate_button = QPushButton("Calculate")
        self.cct_calculate_button.setEnabled(False)
        self.cct_calculate_button.clicked.connect(self._run_cct_calculation)
        cct_actions.addWidget(self.cct_calculate_button)
        layout.addLayout(cct_actions)

        self.cct_progress = QProgressBar()
        self.cct_progress.setMinimum(0)
        self.cct_progress.setMaximum(0)
        self.cct_progress.setVisible(False)
        layout.addWidget(self.cct_progress)

        self._update_cct_ui_state()

    def _browse_touchstone(self) -> None:
        start_dir = self._aedb_path.parent if self._aedb_path else ROOT_DIR
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Touchstone File",
            str(start_dir),
            "Touchstone (*.s*p *.S*p);;All Files (*.*)",
        )
        if file_path:
            self.cct_touchstone_edit.setText(file_path)
            self.status_label.setText(f"Touchstone set to {file_path}")

    def _browse_metadata(self) -> None:
        start_dir = ROOT_DIR
        if self._aedb_path:
            start_dir = self._aedb_path.parent
        elif self._aedb_source_path:
            start_dir = self._aedb_source_path.parent

        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Port Metadata JSON",
            str(start_dir),
            "JSON Files (*.json);;All Files (*.*)",
        )
        if file_path:
            self.cct_json_edit.setText(file_path)
            self._auto_load_cct_metadata()

    def _load_cct_metadata(self) -> None:
        if load_port_metadata is None:
            QMessageBox.warning(
                self,
                "Unavailable",
                "Port metadata loading requires the CCT module. Ensure dependencies are installed.",
            )
            return

        path = self.cct_json_edit.text().strip()
        if not path:
            QMessageBox.warning(self, "Metadata path missing", "Enter a JSON metadata path first.")
            return

        metadata_path = Path(path)
        if not metadata_path.exists():
            QMessageBox.warning(
                self,
                "Metadata not found",
                f"File does not exist:\n{metadata_path}",
            )
            return

        try:
            entries, raw = load_port_metadata(metadata_path)
        except Exception as exc:  # pragma: no cover - runtime feedback path
            self._show_error("Failed to load metadata", exc)
            return

        self._cct_metadata = {"entries": entries, "raw": raw, "path": metadata_path}
        self._populate_cct_table(entries)
        self.status_label.setText(
            f"Loaded {len(entries)} ports from {metadata_path.name}"
        )
        self._update_cct_ui_state()

    def _auto_load_cct_metadata(self) -> None:
        path_str = self.cct_json_edit.text().strip()
        if not path_str:
            if self._cct_metadata is not None or self._cct_port_entries:
                self._cct_metadata = None
                self._cct_port_entries = []
                self.cct_table.setRowCount(0)
            return

        if load_port_metadata is None:
            return

        metadata_path = Path(path_str)
        if not metadata_path.exists():
            return

        current_path = self._cct_metadata.get("path") if self._cct_metadata else None
        if current_path and Path(current_path) == metadata_path:
            return

        try:
            entries, raw = load_port_metadata(metadata_path)
        except Exception as exc:  # pragma: no cover - runtime feedback path
            self._show_error("Failed to load metadata", exc)
            return

        self._cct_metadata = {"entries": entries, "raw": raw, "path": metadata_path}
        self._populate_cct_table(entries)
        self.status_label.setText(
            f"Loaded {len(entries)} ports from {metadata_path.name}"
        )

    def _populate_cct_table(self, entries: Iterable[object]) -> None:
        rows = self._build_cct_rows(entries)
        self._cct_port_entries = list(entries)
        self.cct_table.setRowCount(len(rows))

        for row_index, row in enumerate(rows):
            tx_item = QTableWidgetItem(row["tx_display"])
            rx_item = QTableWidgetItem(row["rx_display"])
            type_item = QTableWidgetItem(row["type"])
            pair_item = QTableWidgetItem(row.get("pair", ""))

            for item in (tx_item, rx_item, type_item, pair_item):
                item.setFlags(item.flags() ^ Qt.ItemIsEditable)

            self.cct_table.setItem(row_index, 0, tx_item)
            self.cct_table.setItem(row_index, 1, rx_item)
            self.cct_table.setItem(row_index, 2, type_item)
            self.cct_table.setItem(row_index, 3, pair_item)

            if row.get("is_diff") and DIFF_ROW_BRUSH is not None:
                for column in range(4):
                    self.cct_table.item(row_index, column).setBackground(DIFF_ROW_BRUSH)

        if not rows:
            self.cct_table.clearContents()

    def _build_cct_rows(self, entries: Iterable[object]) -> List[Dict[str, object]]:
        singles_ctrl: Dict[str, List[object]] = {}
        singles_dram: Dict[str, List[object]] = {}
        diff_ctrl: Dict[Tuple[str, str], Dict[str, object]] = {}
        diff_dram: Dict[Tuple[str, str], Dict[str, object]] = {}

        for entry in entries:
            role = getattr(entry, "component_role", "")
            net_type = getattr(entry, "net_type", "single")
            net_name = getattr(entry, "net", "")

            if net_type == "differential":
                pair_label = getattr(entry, "pair", None) or net_name
                key = (getattr(entry, "component", ""), pair_label)
                target = diff_ctrl if role == "controller" else diff_dram if role == "dram" else None
                if target is None:
                    continue
                mapping = target.setdefault(key, {})
                polarity = getattr(entry, "polarity", None) or (
                    "positive" if "positive" not in mapping else "negative"
                )
                mapping[polarity] = entry
            else:
                target_single = singles_ctrl if role == "controller" else singles_dram if role == "dram" else None
                if target_single is None:
                    continue
                target_single.setdefault(net_name, []).append(entry)

        rows: List[Dict[str, object]] = []

        all_single_nets = sorted(set(list(singles_ctrl.keys()) + list(singles_dram.keys())))
        for net in all_single_nets:
            ctrl_entries = singles_ctrl.get(net, [])
            dram_entries = singles_dram.get(net, [])
            if ctrl_entries and dram_entries:
                for ctrl in ctrl_entries:
                    for dram in dram_entries:
                        rows.append(
                            {
                                "type": "Single",
                                "tx_display": getattr(ctrl, "name", ""),
                                "rx_display": getattr(dram, "name", ""),
                                "pair": net,
                                "is_diff": False,
                            }
                        )
            elif ctrl_entries:
                for ctrl in ctrl_entries:
                    rows.append(
                        {
                            "type": "Single",
                            "tx_display": getattr(ctrl, "name", ""),
                            "rx_display": "(none)",
                            "pair": net,
                            "is_diff": False,
                        }
                    )
            else:
                for dram in dram_entries:
                    rows.append(
                        {
                            "type": "Single",
                            "tx_display": "(none)",
                            "rx_display": getattr(dram, "name", ""),
                            "pair": net,
                            "is_diff": False,
                        }
                    )

        def build_diff_map(source: Dict[Tuple[str, str], Dict[str, object]]) -> Dict[Tuple[str, str], List[Dict[str, object]]]:
            result: Dict[Tuple[str, str], List[Dict[str, object]]] = {}
            for (_, pair_label), mapping in source.items():
                pos_entry = mapping.get("positive")
                neg_entry = mapping.get("negative")
                if not pos_entry or not neg_entry:
                    continue
                signature = tuple(sorted([getattr(pos_entry, "net", ""), getattr(neg_entry, "net", "")]))
                label = getattr(pos_entry, "pair", None) or getattr(neg_entry, "pair", None)
                if not label:
                    label = f"{getattr(pos_entry, 'name', '')}/{getattr(neg_entry, 'name', '')}"
                result.setdefault(signature, []).append(
                    {
                        "label": label,
                        "positive": pos_entry,
                        "negative": neg_entry,
                    }
                )
            return result

        ctrl_pairs = build_diff_map(diff_ctrl)
        dram_pairs = build_diff_map(diff_dram)
        all_signatures = sorted(set(ctrl_pairs.keys()) | set(dram_pairs.keys()))

        for signature in all_signatures:
            ctrl_list = ctrl_pairs.get(signature, [])
            dram_list = dram_pairs.get(signature, [])
            pair_label = ctrl_list[0]["label"] if ctrl_list else (dram_list[0]["label"] if dram_list else "/".join(signature))

            if ctrl_list and dram_list:
                for ctrl in ctrl_list:
                    for dram in dram_list:
                        rows.append(
                            {
                                "type": "Differential",
                                "tx_display": f"{getattr(ctrl['positive'], 'name', '')} / {getattr(ctrl['negative'], 'name', '')}",
                                "rx_display": f"{getattr(dram['positive'], 'name', '')} / {getattr(dram['negative'], 'name', '')}",
                                "pair": pair_label,
                                "is_diff": True,
                            }
                        )
            elif ctrl_list:
                for ctrl in ctrl_list:
                    rows.append(
                        {
                            "type": "Differential",
                            "tx_display": f"{getattr(ctrl['positive'], 'name', '')} / {getattr(ctrl['negative'], 'name', '')}",
                            "rx_display": "(none)",
                            "pair": pair_label,
                            "is_diff": True,
                        }
                    )
            else:
                for dram in dram_list:
                    rows.append(
                        {
                            "type": "Differential",
                            "tx_display": "(none)",
                            "rx_display": f"{getattr(dram['positive'], 'name', '')} / {getattr(dram['negative'], 'name', '')}",
                            "pair": pair_label,
                            "is_diff": True,
                        }
                    )

        rows.sort(key=lambda row: (row["type"], row.get("pair", ""), row["tx_display"], row["rx_display"]))
        return rows

    def _persist_cct_settings(self) -> None:
        if not getattr(self, "_settings", None):
            return
        for key, spin in self._cct_param_spins.items():
            self._settings.setValue(f"cct/{key}", spin.value())
        self._settings.sync()

    def _restore_cct_settings(self) -> None:
        if not getattr(self, "_settings", None):
            return
        stored: Dict[str, float] = {}
        for key, default in DEFAULT_CCT_SETTINGS.items():
            value = self._settings.value(f"cct/{key}", default)
            try:
                stored[key] = float(value)
            except (TypeError, ValueError):
                stored[key] = default
        self._apply_cct_values(stored, persist=False)

    def _current_cct_settings(self) -> Dict[str, float]:
        values: Dict[str, float] = {}
        for key, default in DEFAULT_CCT_SETTINGS.items():
            spin = self._cct_param_spins.get(key)
            values[key] = float(spin.value()) if spin is not None else default
        return values

    @staticmethod
    def _format_with_unit(value: float, unit: str) -> str:
        return f"{value:g}{unit}"

    def _apply_cct_values(self, values: Dict[str, float], persist: bool = True) -> None:
        for key, raw_value in values.items():
            spin = self._cct_param_spins.get(key)
            if spin is None:
                continue
            default = DEFAULT_CCT_SETTINGS.get(key, 0.0)
            try:
                numeric = float(raw_value)
            except (TypeError, ValueError):
                numeric = default
            was_blocked = spin.blockSignals(True)
            spin.setValue(numeric)
            spin.blockSignals(was_blocked)
        if persist:
            self._persist_cct_settings()

    def _save_cct_config(self) -> None:
        params = self._current_cct_settings()
        grouped = {
            group: {key: params[key] for key in keys if key in params}
            for group, keys in CCT_PARAM_GROUPS.items()
        }

        start_dir = self._aedb_path.parent if self._aedb_path else ROOT_DIR
        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Save CCT Parameters",
            str(start_dir),
            "JSON Files (*.json);;All Files (*.*)",
        )
        if not filename:
            return

        try:
            with open(filename, "w", encoding="utf-8") as handle:
                json.dump(grouped, handle, indent=2)
        except Exception as exc:
            self._show_error("Failed to save CCT config", exc)
            return

        self.status_label.setText(f"Saved CCT config to {filename}")

    def _load_cct_config(self) -> None:
        start_dir = self._aedb_path.parent if self._aedb_path else ROOT_DIR
        filename, _ = QFileDialog.getOpenFileName(
            self,
            "Load CCT Parameters",
            str(start_dir),
            "JSON Files (*.json);;All Files (*.*)",
        )
        if not filename:
            return

        try:
            with open(filename, "r", encoding="utf-8") as handle:
                data = json.load(handle)
        except Exception as exc:
            self._show_error("Failed to load CCT config", exc)
            return

        if not isinstance(data, dict):
            QMessageBox.warning(self, "Invalid config", "Selected JSON does not contain an object.")
            return

        extracted: Dict[str, float] = {}
        if any(group in data for group in CCT_PARAM_GROUPS):
            for group, keys in CCT_PARAM_GROUPS.items():
                section = data.get(group, {})
                if not isinstance(section, dict):
                    continue
                for key in keys:
                    if key in section:
                        extracted[key] = section[key]
        else:
            for key in DEFAULT_CCT_SETTINGS:
                if key in data:
                    extracted[key] = data[key]

        if not extracted:
            QMessageBox.warning(self, "No parameters", "No recognized CCT parameters were found in the file.")
            return

        self._apply_cct_values(extracted, persist=True)
        self.status_label.setText(f"Loaded CCT config from {filename}")

    def _reset_cct_config(self) -> None:
        self._apply_cct_values(DEFAULT_CCT_SETTINGS, persist=True)
        self.status_label.setText("CCT parameters reset to defaults")

    def _update_cct_ui_state(self) -> None:
        button = getattr(self, "cct_calculate_button", None)
        if button is None:
            return

        self._auto_load_cct_metadata()

        touchstone_path = self.cct_touchstone_edit.text().strip()
        metadata_path = self.cct_json_edit.text().strip()
        metadata_loaded = bool(self._cct_metadata)
        backend_ready = CCT is not None and load_port_metadata is not None
        button.setEnabled(bool(touchstone_path) and bool(metadata_path) and metadata_loaded and backend_ready)

    def _run_cct_calculation(self) -> None:
        if CCT is None:
            QMessageBox.warning(
                self,
                "Unavailable",
                "CCT backend is not available. Ensure required dependencies are installed.",
            )
            return

        touchstone_path = Path(self.cct_touchstone_edit.text().strip())
        metadata_path = Path(self.cct_json_edit.text().strip())

        if not touchstone_path.exists():
            QMessageBox.warning(
                self,
                "Touchstone missing",
                f"Touchstone file not found:\n{touchstone_path}",
            )
            return

        if not metadata_path.exists():
            QMessageBox.warning(
                self,
                "Metadata missing",
                f"Port metadata file not found:\n{metadata_path}",
            )
            return

        output_path = metadata_path.with_name(f"{metadata_path.stem}_cct.csv")

        workdir = metadata_path.parent / "cct_work"

        QApplication.setOverrideCursor(Qt.WaitCursor)
        self.cct_progress.setVisible(True)
        QApplication.processEvents()
        try:
            cct = CCT(str(touchstone_path), str(metadata_path), workdir=workdir)
            params = self._current_cct_settings()
            cct.set_txs(
                vhigh=self._format_with_unit(params["vhigh"], "V"),
                t_rise=self._format_with_unit(params["t_rise"], "ps"),
                ui=self._format_with_unit(params["ui"], "ps"),
                res_tx=self._format_with_unit(params["res_tx"], "ohm"),
                cap_tx=self._format_with_unit(params["cap_tx"], "pF"),
            )
            cct.set_rxs(
                res_rx=self._format_with_unit(params["res_rx"], "ohm"),
                cap_rx=self._format_with_unit(params["cap_rx"], "pF"),
            )
            cct.run(
                tstep=self._format_with_unit(params["tstep"], "ps"),
                tstop=self._format_with_unit(params["tstop"], "ns"),
            )
            cct.calculate(output_path=str(output_path))
        except ImportError as exc:  # pragma: no cover - runtime feedback path
            QApplication.restoreOverrideCursor()
            self.cct_progress.setVisible(False)
            self._show_error("CCT dependency missing", exc)
            self.status_label.setText("CCT dependencies not available")
            return
        except Exception as exc:  # pragma: no cover - runtime feedback path
            QApplication.restoreOverrideCursor()
            self.cct_progress.setVisible(False)
            self._show_error("CCT calculation failed", exc)
            self.status_label.setText("CCT calculation failed")
            return
        finally:
            QApplication.restoreOverrideCursor()
            self.cct_progress.setVisible(False)

        QMessageBox.information(
            self,
            "CCT complete",
            f"CCT calculation finished.\nResults saved to {output_path}",
        )
        self.status_label.setText(f"CCT results saved to {output_path}")
    def _prompt_for_aedb(self) -> None:
        start_dir = str(Path.cwd())
        dialog = QFileDialog(self, "Select AEDB Directory")
        dialog.setFileMode(QFileDialog.Directory)
        dialog.setOption(QFileDialog.ShowDirsOnly, True)
        dialog.setDirectory(start_dir)
        if dialog.exec():
            selected = dialog.selectedFiles()
            if selected:
                self._load_aedb(Path(selected[0]))

    def _load_aedb(self, path: Path) -> None:
        try:
            if not path.exists():
                raise FileNotFoundError(f"AEDB path does not exist: {path}")
            self._close_edb()
            self.status_label.setText(f"Loading AEDB using {QT_LIB}?")
            QApplication.processEvents()
            self._edb = Edb(str(path), edbversion=self._edb_version)
            self._aedb_path = path
            self._aedb_source_path = path
            self.file_label.setText(str(path))
            self._populate_components()
            self.status_label.setText(
                f"Loaded design with {len(self._components)} components (Uxxx)"
            )
        except Exception as exc:  # pragma: no cover - GUI feedback path
            self._show_error("Failed to load AEDB", exc)
            self.status_label.setText("Failed to load design")
            self._close_edb()

    def _close_edb(self) -> None:
        if self._edb is not None:
            try:
                self._edb.close()
            except Exception:
                pass
            finally:
                self._edb = None
                self._components.clear()
                self.controller_list.clear()
                self.dram_list.clear()
                self.single_list.clear()
                self.diff_list.clear()
                self._update_reference_combo([])
                self._aedb_path = None
                self._aedb_source_path = None
                self._component_nets.clear()
                self._cct_metadata = None
                self._cct_port_entries = []
                if hasattr(self, "cct_table"):
                    self.cct_table.setRowCount(0)
                self._update_action_state()
                self._update_cct_ui_state()

    def _populate_components(self) -> None:
        self.controller_list.blockSignals(True)
        self.dram_list.blockSignals(True)
        self.controller_list.clear()
        self.dram_list.clear()
        self._component_nets.clear()

        if self._edb is None:
            self._update_reference_combo([])
            return

        components = getattr(self._edb.components, "components", {})
        filtered = [
            (name, comp, self._pin_count(comp))
            for name, comp in components.items()
            if self._matches_component_pattern(name)
        ]
        filtered.sort(key=lambda item: (-item[2], item[0]))

        self._components = {name: comp for name, comp, _ in filtered}
        for name, _, pin_count in filtered:
            nets = self._extract_net_names(self._components[name])
            self._component_nets[name] = nets
            label = f"{name} ({pin_count})"
            for list_widget in (self.controller_list, self.dram_list):
                item = QListWidgetItem(label)
                item.setData(Qt.UserRole, name)
                list_widget.addItem(item)

        self.controller_list.blockSignals(False)
        self.dram_list.blockSignals(False)
        self._update_results()

    def _update_results(self) -> None:
        self.single_list.clear()
        self.diff_list.clear()

        if self._edb is None:
            self._update_reference_combo([])
            self.status_label.setText("Load an AEDB to see nets")
            self._update_action_state()
            return

        controller_names = self._selected_component_names(self.controller_list)
        dram_names = self._selected_component_names(self.dram_list)

        if not controller_names or not dram_names:
            self._update_reference_combo([])
            self.status_label.setText(
                "Select at least one controller and one DRAM component"
            )
            self._update_action_state()
            return

        controller_nets = self._collect_net_names(controller_names)
        dram_nets = self._collect_net_names(dram_names)
        shared_nets = sorted(controller_nets & dram_nets)

        all_selected = controller_names + dram_names
        common_nets = self._nets_in_all_components(all_selected)
        self._update_reference_combo(common_nets)

        diff_pairs = self._shared_diff_pairs(shared_nets)
        diff_net_names = {name for _, pos, neg in diff_pairs for name in (pos, neg)}
        filtered_single_nets = [net for net in shared_nets if net not in diff_net_names]

        for net_name in filtered_single_nets:
            item = QListWidgetItem(net_name)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Unchecked)
            self.single_list.addItem(item)

        for pair_name, pos_name, neg_name in diff_pairs:
            label = f"{pair_name}: {pos_name} / {neg_name}"
            item = QListWidgetItem(label)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Unchecked)
            self.diff_list.addItem(item)

        single_count = len(filtered_single_nets)
        diff_count = len(diff_pairs)
        self.status_label.setText(
            f"Controllers: {len(controller_names)} | DRAMs: {len(dram_names)} | "
            f"Shared nets: {single_count} | Shared differential pairs: {diff_count}"
        )
        self._update_action_state()

    def _collect_net_names(self, component_names: Iterable[str]) -> set[str]:
        names: set[str] = set()
        for name in component_names:
            component = self._components.get(name)
            if component is None:
                continue
            cached = self._component_nets.get(name)
            if cached is None:
                cached = self._extract_net_names(component)
                self._component_nets[name] = cached
            names.update(cached)
        return names

    def _checked_diff_entries(self) -> List[Dict[str, str]]:
        entries: List[Dict[str, str]] = []
        for index in range(self.diff_list.count()):
            item = self.diff_list.item(index)
            if item is None or item.checkState() != Qt.Checked:
                continue
            text = item.text()
            if ": " in text:
                pair_name, payload = text.split(": ", 1)
            else:
                pair_name, payload = text, text
            parts = [token.strip() for token in payload.split("/")]
            if len(parts) != 2:
                continue
            pos_name, neg_name = parts
            if pos_name:
                entries.append(
                    {
                        "net": pos_name,
                        "pair": pair_name.strip(),
                        "polarity": "positive",
                    }
                )
            if neg_name:
                entries.append(
                    {
                        "net": neg_name,
                        "pair": pair_name.strip(),
                        "polarity": "negative",
                    }
                )
        return entries

    def _checked_single_nets(self) -> List[str]:
        nets: List[str] = []
        for index in range(self.single_list.count()):
            item = self.single_list.item(index)
            if item is not None and item.checkState() == Qt.Checked:
                nets.append(item.text())
        return nets

    def _checked_diff_nets(self) -> List[str]:
        return [entry["net"] for entry in self._checked_diff_entries()]

    def _checked_net_names(self) -> List[str]:
        ordered = self._checked_single_nets() + self._checked_diff_nets()
        seen: set[str] = set()
        unique: List[str] = []
        for net in ordered:
            if net not in seen:
                seen.add(net)
                unique.append(net)
        return unique

    def _checked_net_metadata(self) -> Dict[str, Dict[str, Optional[str]]]:
        metadata: Dict[str, Dict[str, Optional[str]]] = {}
        for net in self._checked_single_nets():
            metadata[net] = {"type": "single"}
        for entry in self._checked_diff_entries():
            metadata[entry["net"]] = {
                "type": "differential",
                "pair": entry.get("pair"),
                "polarity": entry.get("polarity"),
            }
        return metadata

    def _selected_reference_net(self) -> Optional[str]:
        if not self.reference_combo.isEnabled():
            return None
        text = self.reference_combo.currentText().strip()
        if not text or text == "Select reference net...":
            return None
        return text

    def _update_action_state(self) -> None:
        button = getattr(self, "apply_button", None)
        if button is None or self.port_count_label is None:
            return

        checked_nets = self._checked_net_names()
        controllers = self._selected_component_names(self.controller_list)
        drams = self._selected_component_names(self.dram_list)
        selected_components = controllers + drams
        estimated_ports = self._estimate_port_count(checked_nets, selected_components)
        self.port_count_label.setText(
            f"Checked nets: {len(checked_nets)} | Ports: {estimated_ports}"
        )

        has_edb = self._edb is not None
        has_reference = self._selected_reference_net() is not None
        has_nets = bool(checked_nets)
        has_controller = bool(controllers)
        has_dram = bool(drams)

        button.setEnabled(has_edb and has_reference and has_nets and has_controller and has_dram)
        self._update_cct_ui_state()

    def _estimate_port_count(
        self, net_names: Iterable[str], component_names: Iterable[str]
    ) -> int:
        if not net_names or not component_names:
            return 0

        total = 0
        net_set = set(net_names)
        for component_name in component_names:
            nets = self._component_nets.get(component_name)
            if nets is None:
                component = self._components.get(component_name)
                if component is None:
                    continue
                nets = self._extract_net_names(component)
                self._component_nets[component_name] = nets
            total += len(net_set & nets)
        return total

    def _write_port_metadata(
        self,
        metadata: List[Dict[str, Optional[str]]],
        aedb_path: Path,
        reference_net: str,
        controllers: List[str],
        drams: List[str],
    ) -> Path:
        if not metadata:
            raise ValueError("No port metadata available to write.")

        normalized = []
        for index, entry in enumerate(metadata, 1):
            normalized.append(
                {
                    "sequence": index,
                    "name": entry.get("name"),
                    "component": entry.get("component"),
                    "component_role": entry.get("component_role"),
                    "net": entry.get("net"),
                    "net_type": entry.get("net_type"),
                    "pair": entry.get("pair"),
                    "polarity": entry.get("polarity"),
                    "reference_net": reference_net,
                }
            )

        data = {
            "aedb_path": str(aedb_path),
            "reference_net": reference_net,
            "controller_components": controllers,
            "dram_components": drams,
            "ports": normalized,
        }

        json_path = aedb_path.parent / f"{aedb_path.stem}_ports.json"
        with json_path.open("w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2)

        return json_path

    def _after_metadata_saved(self, json_path: Path) -> None:
        self.cct_json_edit.setText(str(json_path))
        if load_port_metadata is not None:
            self._load_cct_metadata()
        else:
            self._update_cct_ui_state()

    def _apply_changes(self) -> None:
        if self._edb is None:
            QMessageBox.warning(self, "No design", "Load an AEDB design before applying changes.")
            return

        nets = self._checked_net_names()
        if not nets:
            QMessageBox.warning(self, "No nets selected", "Check at least one net before applying changes.")
            return

        reference_net = self._selected_reference_net()
        if reference_net is None:
            QMessageBox.warning(self, "No reference net", "Select a reference net before applying changes.")
            return

        controller_names = self._selected_component_names(self.controller_list)
        dram_names = self._selected_component_names(self.dram_list)
        if not controller_names or not dram_names:
            QMessageBox.warning(
                self,
                "Incomplete selection",
                "Select at least one controller and one DRAM component before applying changes.",
            )
            return

        components = controller_names + dram_names
        component_roles = {name: "controller" for name in controller_names}
        component_roles.update({name: "dram" for name in dram_names})
        net_metadata = self._checked_net_metadata()

        try:
            port_metadata = self._create_ports_for_nets(
                nets,
                reference_net,
                components,
                component_roles,
                net_metadata,
            )
        except Exception as exc:  # pragma: no cover - runtime feedback path
            self._show_error("Failed to create ports", exc)
            return

        ports_created = len(port_metadata)
        saved_path: Optional[Path] = None
        if ports_created > 0:
            try:
                saved_path = self._save_modified_design()
            except Exception as exc:  # pragma: no cover - runtime feedback path
                self._show_error("Failed to save AEDB", exc)
                self.status_label.setText("Failed to save AEDB; see error details.")
                self._update_action_state()
                return

        json_path: Optional[Path] = None
        if ports_created > 0 and saved_path is not None:
            try:
                json_path = self._write_port_metadata(
                    port_metadata,
                    saved_path,
                    reference_net,
                    controller_names,
                    dram_names,
                )
                self._after_metadata_saved(json_path)
            except Exception as exc:  # pragma: no cover - runtime feedback path
                self._show_error("Failed to write port metadata", exc)
                self.status_label.setText("Failed to write port metadata; see error details.")
                self._update_action_state()
                return

        if ports_created == 0:
            QMessageBox.information(
                self,
                "Apply complete",
                "No matching component pins were found for the checked nets.",
            )
        elif saved_path is None:
            QMessageBox.information(
                self,
                "Apply complete",
                f"Created {ports_created} ports referencing {reference_net}.\n"
                "Design was not saved to a new AEDB.",
            )
        else:
            QMessageBox.information(
                self,
                "Apply complete",
                f"Created {ports_created} ports referencing {reference_net}.\n"
                f"Saved to {saved_path}" + (
                    f"\nPort metadata: {json_path}" if json_path else ""
                ),
            )

        if saved_path is not None:
            if json_path is not None:
                self.status_label.setText(
                    f"Created {ports_created} ports, saved to {saved_path}, metadata {json_path}"
                )
            else:
                self.status_label.setText(
                    f"Created {ports_created} ports and saved to {saved_path}"
                )
        else:
            self.status_label.setText(
                f"Created {ports_created} ports for {len(nets)} nets using {reference_net}"
            )
        self._update_action_state()

    def _default_output_path(self) -> Optional[Path]:
        source = self._aedb_source_path or self._aedb_path
        if source is None:
            return None
        stem = source.stem
        stem = re.sub(r"(_applied)+$", "", stem)
        if not stem:
            stem = source.stem
        return source.with_name(f"{stem}_applied.aedb")

    def _save_modified_design(self) -> Optional[Path]:
        if self._edb is None:
            return None

        target = self._default_output_path()
        if target is None:
            return None

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            self._edb.save_edb_as(str(target))
            try:
                self._edb.close_edb()
            except Exception:
                pass

            try:
                new_edb = Edb(str(target), edbversion=self._edb_version)
            except Exception:
                self._edb = None
                self._aedb_path = None
                self._components.clear()
                self.controller_list.clear()
                self.dram_list.clear()
                self.single_list.clear()
                self.diff_list.clear()
                self._update_reference_combo([])
                raise
        finally:
            QApplication.restoreOverrideCursor()

        self._edb = new_edb
        self._aedb_path = target
        self.file_label.setText(str(target))
        self._populate_components()
        return target

    def _create_ports_for_nets(
        self,
        net_names: Iterable[str],
        reference_net: str,
        component_names: Iterable[str],
        component_roles: Dict[str, str],
        net_metadata: Dict[str, Dict[str, Optional[str]]],
    ) -> List[Dict[str, Optional[str]]]:
        if self._edb is None:
            return []

        edb = self._edb
        nets_container = getattr(edb.nets, "nets", {})
        if isinstance(nets_container, dict):
            nets_lookup = nets_container
        else:
            nets_lookup = dict(getattr(nets_container, "items", lambda: [])())

        component_set = set(component_names)
        component_order = {name: idx for idx, name in enumerate(component_names)}
        reference_terminals: Dict[str, object] = {}
        metadata: List[Dict[str, Optional[str]]] = []

        for net_name in net_names:
            net_obj = nets_lookup.get(net_name)
            if net_obj is None:
                continue

            net_components = getattr(net_obj, "components", {})
            if isinstance(net_components, dict):
                component_iterable = list(net_components.keys())
            else:
                component_iterable = list(net_components)

            component_iterable.sort(key=lambda name: component_order.get(name, len(component_order)))

            for component_name in component_iterable:
                if component_name not in component_set:
                    continue
                if component_name not in self._components:
                    continue

                reference_terminal = reference_terminals.get(component_name)
                if reference_terminal is None:
                    reference_terminal = self._create_reference_terminal(component_name, reference_net)
                    if reference_terminal is None:
                        continue
                    reference_terminals[component_name] = reference_terminal

                signal_terminal = self._create_signal_terminal(component_name, net_name)
                if signal_terminal is None:
                    continue

                base_port_name = f"{component_name}_{net_name}"
                sequence = len(metadata) + 1
                port_name = prefix_port_name(base_port_name, sequence)
                if hasattr(signal_terminal, "SetName"):
                    signal_terminal.SetName(port_name)
                if hasattr(signal_terminal, "SetReferenceTerminal"):
                    signal_terminal.SetReferenceTerminal(reference_terminal)
                net_info = net_metadata.get(net_name, {"type": "single"})
                metadata.append(
                    {
                        "sequence": sequence,
                        "name": port_name,
                        "component": component_name,
                        "component_role": component_roles.get(component_name, "unknown"),
                        "net": net_name,
                        "net_type": net_info.get("type", "single"),
                        "pair": net_info.get("pair"),
                        "polarity": net_info.get("polarity"),
                    }
                )

        return metadata

    def _create_reference_terminal(self, component_name: str, reference_net: str):
        group_name = self._sanitized_group_name(component_name, reference_net, suffix="ref")
        pin_group = self._ensure_pin_group(component_name, reference_net, group_name)
        if pin_group is None:
            return None

        terminal = pin_group.create_port_terminal(50)
        if hasattr(terminal, "SetName"):
            terminal.SetName(f"ref;{component_name};{reference_net}")
        return terminal

    def _create_signal_terminal(self, component_name: str, net_name: str):
        group_name = self._sanitized_group_name(component_name, net_name)
        pin_group = self._ensure_pin_group(component_name, net_name, group_name)
        if pin_group is None:
            return None
        return pin_group.create_port_terminal(50)

    def _ensure_pin_group(self, component_name: str, net_name: str, group_name: str):
        if self._edb is None:
            return None

        result = self._edb.core_siwave.create_pin_group_on_net(component_name, net_name, group_name)
        return self._pin_group_from_result(result)

    @staticmethod
    def _pin_group_from_result(result):
        candidates = []
        if isinstance(result, (list, tuple)):
            candidates.extend(result)
        else:
            candidates.append(result)

        for entry in reversed(candidates):
            if hasattr(entry, "create_port_terminal"):
                return entry
        return None

    @staticmethod
    def _sanitized_group_name(component_name: str, net_name: str, suffix: Optional[str] = None) -> str:
        base = f"{component_name}_{net_name}"
        safe = re.sub(r"[^A-Za-z0-9_]+", "_", base)
        safe = re.sub(r"_+", "_", safe).strip("_")
        if suffix:
            safe = f"{safe}_{suffix}" if safe else suffix
        if not safe:
            fallback = re.sub(r"[^A-Za-z0-9_]+", "_", component_name).strip("_") or "comp"
            suffix_part = suffix or "pg"
            safe = f"{fallback}_{suffix_part}"
        return safe

    def _nets_in_all_components(self, component_names: Iterable[str]) -> List[str]:
        valid_names = [name for name in component_names if self._components.get(name) is not None]
        if not valid_names:
            return []

        common: set[str] | None = None
        for name in valid_names:
            nets = self._extract_net_names(self._components[name])
            if common is None:
                common = set(nets)
            else:
                common &= nets
            if not common:
                break

        return sorted(common or [])

    def _update_reference_combo(self, common_nets: Iterable[str]) -> None:
        nets = sorted(set(common_nets))
        self.reference_combo.blockSignals(True)
        self.reference_combo.clear()

        if not nets:
            self.reference_combo.addItem("Select reference net...")
            self.reference_combo.setEnabled(False)
            self.reference_combo.blockSignals(False)
            self._update_action_state()
            return

        self.reference_combo.setEnabled(True)
        self.reference_combo.addItem("Select reference net...")
        for net in nets:
            self.reference_combo.addItem(net)

        default_net = next((net for net in nets if "gnd" in net.lower()), None)
        if default_net:
            index = self.reference_combo.findText(default_net)
            if index != -1:
                self.reference_combo.setCurrentIndex(index)
        else:
            self.reference_combo.setCurrentIndex(0)

        self.reference_combo.blockSignals(False)
        self._update_action_state()

    def _shared_diff_pairs(self, shared_nets: Iterable[str]) -> List[Tuple[str, str, str]]:
        if self._edb is None:
            return []

        shared_set = set(shared_nets)
        diff_container = getattr(self._edb, "differential_pairs", None)
        if diff_container is None:
            return []

        try:
            items_attr = diff_container.items
        except AttributeError:
            return []

        if callable(items_attr):
            candidates = items_attr()
            if isinstance(candidates, dict):
                iterator = candidates.items()
            else:
                iterator = candidates
        elif isinstance(items_attr, dict):
            iterator = items_attr.items()
        else:
            iterator = []

        matches: List[Tuple[str, str, str]] = []
        for name, diff in iterator:
            pos = getattr(diff, "positive_net", None)
            neg = getattr(diff, "negative_net", None)
            pos_name = getattr(pos, "name", None)
            neg_name = getattr(neg, "name", None)
            if pos_name in shared_set and neg_name in shared_set:
                matches.append((name, pos_name, neg_name))

        return sorted(matches, key=lambda item: item[0])

    @staticmethod
    def _extract_net_names(component: object) -> set[str]:
        names: set[str] = set()
        nets = getattr(component, "nets", [])
        if isinstance(nets, dict):
            iterable = nets.values()
        else:
            iterable = nets
        for net in iterable:
            if isinstance(net, str):
                names.add(net)
            else:
                name = getattr(net, "name", None)
                if name:
                    names.add(name)
        return names

    @staticmethod
    def _selected_component_names(list_widget: QListWidget) -> List[str]:
        names: List[str] = []
        for item in list_widget.selectedItems():
            name = item.data(Qt.UserRole)
            if isinstance(name, str) and name:
                names.append(name)
            else:
                names.append(item.text())
        return names

    @staticmethod
    def _pin_count(component: object) -> int:
        pins = getattr(component, "pins", None)
        if pins is None:
            return 0
        try:
            keys = getattr(pins, "keys", None)
            if callable(keys):
                return len(list(keys()))
        except Exception:
            pass
        try:
            return len(pins)
        except TypeError:
            return sum(1 for _ in getattr(pins, "values", lambda: [])())

    @staticmethod
    def _matches_component_pattern(name: str) -> bool:
        return bool(_COMPONENT_PATTERN.match(name))

    def _show_error(self, title: str, exc: Exception) -> None:
        details = "".join(traceback.format_exception(exc))
        QMessageBox.critical(self, title, f"{exc}\n\n{details}")

    def closeEvent(self, event) -> None:  # noqa: D401 - Qt signature
        self._close_edb()
        super().closeEvent(event)


def main() -> None:
    app = QApplication(sys.argv)
    widget = EdbGui()
    widget.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
