import webview
import os
from model import LayoutModel

class API:
    def __init__(self):
        self.model = LayoutModel()

    def open_file_dialog(self):
        file_types = ('Edb Files (*.aedb;*.def;*.gds;*.brd)', 'All files (*.*)')
        result = webview.windows[0].create_file_dialog(webview.OPEN_DIALOG, allow_multiple=False, file_types=file_types)
        if result:
            return result[0]
        return None

    def load_file(self, file_path):
        print(f"Loading file: {file_path}")
        try:
            data = self.model.load_file(file_path)
            return data
        except Exception as e:
            return {"error": str(e)}

    def close_app(self):
        self.model.close()
        webview.windows[0].destroy()

def main():
    api = API()
    webview.create_window(
        'PCB Layout Viewer', 
        'index.html', 
        js_api=api,
        width=1200,
        height=800
    )
    webview.start(debug=False)

if __name__ == "__main__":
    main()
