// State
let scale = 1;
let offsetX = 0;
let offsetY = 0;
let isDragging = false;
let startX, startY;
let primitives = [];
let layers = [];
let canvas, ctx;

// Initialization
window.addEventListener('DOMContentLoaded', () => {
    canvas = document.getElementById('layout-canvas');
    ctx = canvas.getContext('2d');

    // Resize canvas
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Event Listeners
    canvas.addEventListener('mousedown', startPan);
    canvas.addEventListener('mousemove', pan);
    canvas.addEventListener('mouseup', endPan);
    canvas.addEventListener('wheel', zoom);

    // Close dropdowns when clicking outside
    window.addEventListener('click', (e) => {
        if (!e.target.matches('.menu-item')) {
            document.querySelectorAll('.dropdown').forEach(d => d.classList.remove('show'));
        }
    });

    draw();
});

function resizeCanvas() {
    const container = document.getElementById('canvas-container');
    canvas.width = container.clientWidth;
    canvas.height = container.clientHeight;
    draw();
}

// Menu Logic
function toggleMenu(id) {
    const menu = document.getElementById(id);
    document.querySelectorAll('.dropdown').forEach(d => {
        if (d.id !== id) d.classList.remove('show');
    });
    menu.classList.toggle('show');
}

// API Calls
async function openFile() {
    try {
        const filePath = await window.pywebview.api.open_file_dialog();
        if (filePath) {
            document.getElementById('status-message').innerText = `Loading ${filePath}...`;
            const data = await window.pywebview.api.load_file(filePath);
            if (data.error) {
                alert(`Error loading file: ${data.error}`);
                document.getElementById('status-message').innerText = 'Error';
            } else {
                loadData(data);
                document.getElementById('status-message').innerText = `Loaded ${filePath}`;
            }
        }
    } catch (e) {
        console.error(e);
    }
}

function exitApp() {
    window.pywebview.api.close_app();
}

function showAbout() {
    alert('PCB Layout Viewer v1.0\nPowered by pywebview & pyedb');
}

// Data Handling
function loadData(data) {
    layers = data.layers;
    primitives = data.primitives;

    // Populate Layer List
    const list = document.getElementById('layer-list');
    list.innerHTML = '';

    layers.forEach(layer => {
        const item = document.createElement('div');
        item.className = 'layer-item';
        item.onclick = () => toggleLayer(layer.name);

        const colorInput = document.createElement('input');
        colorInput.type = 'color';
        colorInput.className = 'layer-color-picker';
        // Convert HSL to Hex for input value if needed, or backend can send Hex.
        // The backend sends HSL now. Input type=color expects Hex.
        // We need a helper to convert HSL to Hex or change backend to send Hex.
        // Let's change backend to send Hex for simplicity in next step, 
        // but for now let's assume we handle it or use a simple div if we can't convert easily in JS without lib.
        // Actually, let's just make the backend send Hex. 
        // But wait, I can't change backend in this tool call. 
        // I'll stick to the plan: Update script.js. I'll add a helper to convert HSL string to Hex.

        colorInput.value = hslToHex(layer.color);
        colorInput.onchange = (e) => {
            layer.color = e.target.value;
            draw();
        };
        colorInput.onclick = (e) => e.stopPropagation(); // Prevent item click

        const name = document.createElement('span');
        name.className = 'layer-name';
        name.innerText = layer.name;

        const check = document.createElement('input');
        check.type = 'checkbox';
        check.checked = layer.visible;
        check.onchange = (e) => {
            e.stopPropagation(); // Prevent item click
            layer.visible = e.target.checked;
            draw();
        };

        item.appendChild(colorInput);
        item.appendChild(name);
        item.appendChild(check);
        list.appendChild(item);
    });

    // Auto-fit view
    fitToView();
}

function hslToHex(hsl) {
    // Expects "hsl(h, s%, l%)"
    let [h, s, l] = hsl.match(/\d+/g).map(Number);
    l /= 100;
    const a = s * Math.min(l, 1 - l) / 100;
    const f = n => {
        const k = (n + h / 30) % 12;
        const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
        return Math.round(255 * color).toString(16).padStart(2, '0');
    };
    return `#${f(0)}${f(8)}${f(4)}`;
}

function toggleLayer(name) {
    const layer = layers.find(l => l.name === name);
    if (layer) {
        layer.visible = !layer.visible;
        // Update checkbox
        // Re-render list or just find the checkbox (optimization)
        draw();
    }
}

// Rendering
function draw() {
    // Clear
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.save();

    // Apply Transform
    // Center of canvas is origin for zoom
    ctx.translate(canvas.width / 2 + offsetX, canvas.height / 2 + offsetY);
    ctx.scale(scale, scale);
    // Flip Y because PCB coordinates usually have Y up, canvas has Y down
    ctx.scale(1, -1);

    // Draw Grid (Optional, simple crosshair)
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 1 / scale;
    ctx.beginPath();
    ctx.moveTo(-1000, 0); ctx.lineTo(1000, 0);
    ctx.moveTo(0, -1000); ctx.lineTo(0, 1000);
    ctx.stroke();

    // Draw Primitives
    primitives.forEach(prim => {
        const layer = layers.find(l => l.name === prim.layer);
        if (layer && layer.visible) {
            ctx.fillStyle = layer.color;
            ctx.strokeStyle = layer.color;
            ctx.lineWidth = 1 / scale; // Constant line width

            if (prim.type === 'polygon') {
                ctx.beginPath();
                if (prim.points.length > 0) {
                    ctx.moveTo(prim.points[0][0], prim.points[0][1]);
                    for (let i = 1; i < prim.points.length; i++) {
                        ctx.lineTo(prim.points[i][0], prim.points[i][1]);
                    }
                    ctx.closePath();
                    // Fill with transparency
                    ctx.globalAlpha = 0.5;
                    ctx.fill();
                    ctx.globalAlpha = 1.0;
                    ctx.stroke();
                }
            }
        }
    });

    ctx.restore();
}

function fitToView() {
    if (primitives.length === 0) return;

    // Calculate bounds
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;

    primitives.forEach(p => {
        p.points.forEach(pt => {
            if (pt[0] < minX) minX = pt[0];
            if (pt[0] > maxX) maxX = pt[0];
            if (pt[1] < minY) minY = pt[1];
            if (pt[1] > maxY) maxY = pt[1];
        });
    });

    const width = maxX - minX;
    const height = maxY - minY;

    if (width === 0 || height === 0) return;

    const padding = 1.1;
    const scaleX = canvas.width / (width * padding);
    const scaleY = canvas.height / (height * padding);

    scale = Math.min(scaleX, scaleY);

    // Center
    const centerX = (minX + maxX) / 2;
    const centerY = (minY + maxY) / 2;

    // Offset needs to counteract the translation to center
    // We want (centerX, centerY) to be at (0,0) before canvas center translation
    // So we translate by -centerX, -centerY
    // But our transform is: translate(w/2 + offX, h/2 + offY) -> scale -> translate(-centerX, -centerY) implicitly?
    // No, we translate context.
    // Let's set offsetX/Y such that centerX/Y is at canvas center.
    // Current transform: T(w/2+offX, h/2+offY) * S * T(0,0)
    // We want point (centerX, centerY) to end up at (w/2, h/2)
    // (centerX * scale) + (w/2 + offX) = w/2  <-- this logic is flawed because of the flip

    // Correct logic:
    // We want the center of the bounding box to be at the center of the screen.
    // The draw function does: translate(w/2 + offX, h/2 + offY) then scale then flip Y.
    // So a point (x,y) becomes:
    // X_screen = (x * scale) + (w/2 + offX)
    // Y_screen = (-y * scale) + (h/2 + offY)

    // We want (centerX, centerY) -> (w/2, h/2)
    // w/2 = (centerX * scale) + w/2 + offX  => offX = -centerX * scale
    // h/2 = (-centerY * scale) + h/2 + offY => offY = centerY * scale

    offsetX = -centerX * scale;
    offsetY = centerY * scale;

    draw();
}

// Interaction
function startPan(e) {
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;
}

function pan(e) {
    if (!isDragging) {
        // Update coordinates display
        // Inverse transform to get world coordinates
        const rect = canvas.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        // X_screen = (worldX * scale) + (w/2 + offX)
        // worldX = (X_screen - (w/2 + offX)) / scale
        const worldX = (x - (canvas.width / 2 + offsetX)) / scale;

        // Y_screen = (-worldY * scale) + (h/2 + offY)
        // worldY = -(Y_screen - (h/2 + offY)) / scale
        const worldY = -(y - (canvas.height / 2 + offsetY)) / scale;

        document.getElementById('coordinates').innerText = `${worldX.toFixed(3)}, ${worldY.toFixed(3)}`;
        return;
    }

    const dx = e.clientX - startX;
    const dy = e.clientY - startY;

    offsetX += dx;
    offsetY += dy;

    startX = e.clientX;
    startY = e.clientY;

    draw();
}

function endPan() {
    isDragging = false;
}

function zoom(e) {
    e.preventDefault();

    const zoomIntensity = 0.1;
    const wheel = e.deltaY < 0 ? 1 : -1;
    const zoomFactor = Math.exp(wheel * zoomIntensity);

    // Zoom towards mouse pointer
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    // Current world pos of mouse
    const worldX = (mouseX - (canvas.width / 2 + offsetX)) / scale;
    const worldY = -(mouseY - (canvas.height / 2 + offsetY)) / scale;

    scale *= zoomFactor;

    // Adjust offset to keep mouse at same world pos
    // new_offX = mouseX - w/2 - worldX * new_scale
    offsetX = mouseX - canvas.width / 2 - worldX * scale;
    offsetY = mouseY - canvas.height / 2 + worldY * scale; // Note the + because of -y flip

    draw();
}
