from pyedb import Edb
import os
import random

class LayoutModel:
    def __init__(self):
        self.edb = None

    def _generate_color(self, index, total):
        # Generate distinct colors using HSL
        hue = int((index * 360) / total)
        return f"hsl({hue}, 70%, 50%)"

    def load_file(self, file_path):
        if not os.path.exists(file_path):
            return {"error": "File not found"}

        try:
            # Initialize Edb. Note: version might need to be dynamic or configured
            self.edb = Edb(file_path, version='2024.1')
        except Exception as e:
            return {"error": str(e)}

        layers = []
        primitives = []
        
        # Get stackup layers
        if self.edb.stackup and self.edb.stackup.layers:
            layer_items = list(self.edb.stackup.layers.items())
            total_layers = len(layer_items)
            for i, (layer_name, layer) in enumerate(layer_items):
                layers.append({
                    "name": layer_name,
                    "color": self._generate_color(i, total_layers),
                    "visible": True,
                    "type": layer.type
                })

        # Get primitives
        # Note: This might be slow for large designs. Optimization may be needed.
        if self.edb.modeler and self.edb.modeler.primitives:
            for p in self.edb.modeler.primitives:
                prim_data = {
                    "layer": p.layer_name,
                    "type": "polygon",
                    "points": []
                }
                
                # Extract points
                if p.polygon_data:
                    # points_without_arcs returns a list of points
                    # We need to convert them to a serializable format
                    points = p.polygon_data.points_without_arcs
                    # Assuming points have x and y attributes or are iterable
                    # pyedb points are usually [x, y] or objects with x, y
                    # Let's inspect what points_without_arcs returns in the original script
                    # It printed them directly. Usually they are objects.
                    # We'll try to convert to list of [x, y]
                    
                    serialized_points = []
                    for pt in points:
                        # Check if pt is an object with x, y or a list/tuple
                        if hasattr(pt, 'x') and hasattr(pt, 'y'):
                            serialized_points.append([float(pt.x), float(pt.y)])
                        else:
                             # Fallback if it's already a list/tuple
                            serialized_points.append([float(pt[0]), float(pt[1])])
                    
                    prim_data["points"] = serialized_points
                    primitives.append(prim_data)

        return {
            "layers": layers,
            "primitives": primitives
        }

    def close(self):
        if self.edb:
            self.edb.close_edb()
            self.edb = None

if __name__ == "__main__":
    # Test stub
    model = LayoutModel()
    # result = model.load_file('c:/demo/pcb.brd')
    # print(result)
    model.close()