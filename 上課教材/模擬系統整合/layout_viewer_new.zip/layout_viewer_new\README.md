# PCB 佈局檢視器 (PCB Layout Viewer)

一個輕量級、現代化的桌面應用程式，用於檢視 PCB 佈局，使用 Python 和 Web 技術構建。

## 概述

此工具允許使用者開啟並視覺化 PCB 設計檔案（支援 Ansys PyEDB）。它具有高效能的畫布渲染器、可自訂顏色的圖層管理，以及直覺的導航控制。

## 功能

- **開啟 PCB 設計**：載入 `.brd`、`.aedb` 以及其他 PyEDB 支援的格式。
- **互動式畫布**：流暢的縮放和平移。
- **圖層控制**：切換圖層可見性並自訂圖層顏色。
- **深色模式介面**：專業且護眼的介面設計。
- **跨平台**：可在 Windows（主要）、Linux 和 macOS 上執行。

## 先決條件

- **Python 3.11+**
- **Ansys Electronics Desktop**：`pyedb` 運作所需。

## 安裝

本專案使用 `uv` 進行依賴管理，但也透過 pip 安裝。

### 使用 uv（推薦）
```bash
# 同步依賴套件
uv sync
```

### 使用 pip
```bash
pip install pywebview pyedb
```

## 使用方法

使用主腳本執行應用程式：

```bash
# 使用 uv
uv run main.py

# 或直接使用 python
python main.py
```

## 操作控制

- **檔案 (File) -> 開啟 (Open)**：載入設計檔案。
- **滑鼠滾輪**：放大/縮小。
- **滑鼠拖曳**：平移視圖。
- **圖層列表**：點擊核取方塊切換可見性，點擊顏色框更改顏色。

## 架構

有關詳細的技術規格，請參閱 [spec.md](spec.md)。
