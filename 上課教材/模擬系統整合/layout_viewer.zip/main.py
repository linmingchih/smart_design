import webview
import os
import sys
from model import LayoutModel

# Ensure we can import from current directory
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

class Api:
    def __init__(self):
        self.model = LayoutModel()

    def open_file_dialog(self):
        # file_types is a tuple of strings
        file_types = ('Layout Files (*.brd;*.aedb)', 'All files (*.*)')
        result = window.create_file_dialog(webview.OPEN_DIALOG, allow_multiple=False, file_types=file_types)
        return result[0] if result else None

    def load_layout(self, path):
        try:
            print(f"Loading layout from: {path}")
            self.model.load(path)
            return True
        except Exception as e:
            print(f"Error loading layout: {e}")
            return False

    def get_layers(self):
        try:
            return self.model.get_layers()
        except Exception as e:
            print(f"Error getting layers: {e}")
            return []

    def get_primitives(self):
        try:
            return self.model.get_primitives()
        except Exception as e:
            print(f"Error getting primitives: {e}")
            return []
    
    def exit(self):
        window.destroy()

def main():
    global window
    api = Api()
    # Use absolute path for index.html to avoid issues
    html_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'index.html')
    window = webview.create_window('Layout Viewer', html_path, js_api=api, width=1200, height=800)
    webview.start(debug=True)

if __name__ == "__main__":
    main()
