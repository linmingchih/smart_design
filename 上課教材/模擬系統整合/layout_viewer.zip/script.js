let layers = [];
let primitives = [];
let canvas, ctx;
let scale = 1;
let offsetX = 0;
let offsetY = 0;
let isDragging = false;
let lastX, lastY;

document.addEventListener('DOMContentLoaded', () => {
    canvas = document.getElementById('layout-canvas');
    ctx = canvas.getContext('2d');

    // Resize canvas to fit container
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Event Listeners
    document.getElementById('btn-open').addEventListener('click', openFile);
    document.getElementById('btn-save').addEventListener('click', () => log("Save not implemented yet."));
    document.getElementById('btn-exit').addEventListener('click', () => pywebview.api.exit());

    // Canvas Interaction
    canvas.addEventListener('wheel', handleZoom);
    canvas.addEventListener('mousedown', startPan);
    canvas.addEventListener('mousemove', pan);
    canvas.addEventListener('mouseup', endPan);
    canvas.addEventListener('mouseleave', endPan);
});

function resizeCanvas() {
    const parent = canvas.parentElement;
    canvas.width = parent.clientWidth;
    canvas.height = parent.clientHeight;
    draw();
}

function log(msg) {
    const logDiv = document.getElementById('message-log');
    logDiv.innerText = msg + '\n' + logDiv.innerText;
}

async function openFile() {
    try {
        log("Opening file dialog...");
        const path = await pywebview.api.open_file_dialog();
        if (path) {
            log(`Loading file: ${path}`);
            const success = await pywebview.api.load_layout(path);
            if (success) {
                log("File loaded successfully.");
                await loadLayers();
                await loadPrimitives();
                fitToView();
            } else {
                log("Failed to load file.");
            }
        }
    } catch (e) {
        log("Error: " + e);
    }
}

let layerColors = {};

async function loadLayers() {
    layers = await pywebview.api.get_layers();
    const list = document.getElementById('layer-list');
    list.innerHTML = '';
    layers.forEach(layer => {
        const div = document.createElement('div');
        div.className = 'layer-item';

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.checked = true; // Default visible
        checkbox.id = `layer-${layer}`;
        checkbox.addEventListener('change', draw);

        // Color Input
        const colorInput = document.createElement('input');
        colorInput.type = 'color';
        // Generate initial color if not set
        if (!layerColors[layer]) {
            layerColors[layer] = getColorForLayer(layer);
        }
        colorInput.value = layerColors[layer];
        colorInput.className = 'layer-color';
        // Use 'input' event for real-time updates, or 'change' for update on close
        colorInput.addEventListener('input', (e) => {
            layerColors[layer] = e.target.value;
            draw();
        });

        const label = document.createElement('label');
        label.htmlFor = `layer-${layer}`;
        label.innerText = layer;

        div.appendChild(checkbox);
        div.appendChild(colorInput);
        div.appendChild(label);
        list.appendChild(div);
    });
}

async function loadPrimitives() {
    // Fetch all primitives at once for now. 
    // In a real app, might want to fetch by layer or viewport.
    primitives = await pywebview.api.get_primitives();
    log(`Loaded ${primitives.length} primitives.`);
    draw();
}

function draw() {
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.save();
    // Apply transformations
    ctx.translate(offsetX + canvas.width / 2, offsetY + canvas.height / 2);
    ctx.scale(scale, -scale); // Flip Y axis for standard CAD coordinates usually

    // Draw primitives
    primitives.forEach(prim => {
        const layerCheckbox = document.getElementById(`layer-${prim.layer}`);
        if (layerCheckbox && layerCheckbox.checked) {
            ctx.beginPath();
            if (prim.points && prim.points.length > 0) {
                ctx.moveTo(prim.points[0][0], prim.points[0][1]);
                for (let i = 1; i < prim.points.length; i++) {
                    ctx.lineTo(prim.points[i][0], prim.points[i][1]);
                }
                ctx.closePath();

                const color = layerColors[prim.layer] || '#CCCCCC';

                ctx.strokeStyle = color;
                ctx.lineWidth = 1 / scale; // Keep line width constant on screen
                ctx.stroke();
                ctx.fillStyle = color + "40"; // Semi-transparent fill
                ctx.fill();
            }
        }
    });

    ctx.restore();
}

function getColorForLayer(layerName) {
    // Simple hash for color
    let hash = 0;
    for (let i = 0; i < layerName.length; i++) {
        hash = layerName.charCodeAt(i) + ((hash << 5) - hash);
    }
    const c = (hash & 0x00FFFFFF).toString(16).toUpperCase();
    return '#' + "00000".substring(0, 6 - c.length) + c;
}

function handleZoom(e) {
    e.preventDefault();
    const zoomIntensity = 0.1;
    const wheel = e.deltaY < 0 ? 1 : -1;
    const zoom = Math.exp(wheel * zoomIntensity);

    // Zoom towards mouse pointer logic could be added here
    // For now, simple center zoom
    scale *= zoom;
    draw();
}

function startPan(e) {
    isDragging = true;
    lastX = e.clientX;
    lastY = e.clientY;
}

function pan(e) {
    if (!isDragging) return;
    const dx = e.clientX - lastX;
    const dy = e.clientY - lastY;
    offsetX += dx;
    offsetY += dy;
    lastX = e.clientX;
    lastY = e.clientY;
    draw();
}

function endPan() {
    isDragging = false;
}

function fitToView() {
    if (primitives.length === 0) return;

    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;

    primitives.forEach(p => {
        if (p.points) {
            p.points.forEach(pt => {
                if (pt[0] < minX) minX = pt[0];
                if (pt[0] > maxX) maxX = pt[0];
                if (pt[1] < minY) minY = pt[1];
                if (pt[1] > maxY) maxY = pt[1];
            });
        }
    });

    if (minX === Infinity) return;

    const contentWidth = maxX - minX;
    const contentHeight = maxY - minY;

    const padding = 1.1;
    const scaleX = canvas.width / (contentWidth * padding);
    const scaleY = canvas.height / (contentHeight * padding);

    scale = Math.min(scaleX, scaleY);

    // Center logic
    const centerX = (minX + maxX) / 2;
    const centerY = (minY + maxY) / 2;

    // Reset offset to center the content
    // We want (centerX, centerY) to be at (0,0) in transformed space
    // And then we translate (0,0) to center of canvas (handled in draw)
    // So we just need to offset by -centerX * scale? 
    // Wait, in draw: translate(offsetX + w/2, offsetY + h/2) -> scale
    // So if we want point C to be at center:
    // C * scale + offset = 0 (relative to center)
    // offset = -C * scale

    // Actually, let's just set the translation such that the center of the bounding box is at the center of the screen.
    // In draw(): ctx.translate(offsetX + canvas.width / 2, offsetY + canvas.height / 2);
    // So if offsetX=0, offsetY=0, the origin (0,0) is at the center of the screen.
    // We want (centerX, centerY) to be at the center of the screen.
    // So we need to shift the world by (-centerX, -centerY).
    // Since we scale AFTER translate in the code above? No, translate then scale.
    // ctx.translate(..); ctx.scale(..);
    // So coordinate (x,y) becomes: (x * scale) + transX
    // We want (centerX * scale) + transX = width/2
    // transX = width/2 - centerX * scale
    // In my code: transX = offsetX + width/2
    // So offsetX = -centerX * scale

    // But wait, Y is flipped: ctx.scale(scale, -scale)
    // y_screen = (y * -scale) + transY
    // We want (centerY * -scale) + transY = height/2
    // transY = height/2 + centerY * scale
    // In my code: transY = offsetY + height/2
    // So offsetY = centerY * scale

    // Let's try this:
    offsetX = -centerX * scale;
    offsetY = centerY * scale; // Because of Y-flip

    draw();
}
