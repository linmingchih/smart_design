from pyedb import Edb
import os

class LayoutModel:
    def __init__(self):
        self.edb = None

    def load(self, path):
        if self.edb:
            self.edb.close_edb()
            self.edb = None
        
        if not os.path.exists(path):
            raise FileNotFoundError(f"File not found: {path}")

        # Assuming version 2024.1 as per original snippet, or auto-detect
        try:
            self.edb = Edb(path, version='2024.1')
        except Exception as e:
            # Fallback or re-raise
            print(f"Error loading EDB: {e}")
            raise

    def get_layers(self):
        if not self.edb:
            return []
        # stackup.layers is a dict usually
        return list(self.edb.stackup.layers.keys())

    def get_primitives(self):
        if not self.edb:
            return []
        
        prims = []
        for p in self.edb.modeler.primitives:
            try:
                layer = p.layer_name
                # Get polygon data
                # points_without_arcs returns a list of points
                poly_data = p.polygon_data
                points = poly_data.points_without_arcs
                
                # Convert points to list of [x, y]
                # points are usually objects with x, y properties or similar
                # Let's inspect what points_without_arcs returns in pyedb.
                # Usually it's a list of [x, y] or objects.
                # Based on user snippet `print(data.points_without_arcs)`, it likely prints a list.
                # We'll assume it's iterable.
                
                # Safe conversion
                pts_list = []
                for pt in points:
                    # Check if pt is an object or list/tuple
                    if hasattr(pt, 'x') and hasattr(pt, 'y'):
                        pts_list.append([float(pt.x), float(pt.y)])
                    elif isinstance(pt, (list, tuple)) and len(pt) >= 2:
                        pts_list.append([float(pt[0]), float(pt[1])])
                    else:
                        # Fallback for other types if necessary
                        pass
                
                if pts_list:
                    prims.append({
                        "layer": layer,
                        "points": pts_list
                    })
            except Exception as e:
                print(f"Error processing primitive: {e}")
                continue
                
        return prims

    def close(self):
        if self.edb:
            self.edb.close_edb()
            self.edb = None