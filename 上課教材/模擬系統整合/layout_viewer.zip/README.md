# Layout Viewer (佈局檢視器)

Layout Viewer 是一個基於 Python 的桌面應用程式，專為檢視 Ansys 佈局檔案（如 `.brd` 和 `.aedb`）而設計。它結合了 `pywebview` 的現代化圖形使用者介面 (GUI) 與 `pyedb` 的強大後端處理能力，提供流暢且直觀的佈局檢視體驗。

## 主要功能 (Features)

### 1. 檔案讀取 (File Loading)
- **支援格式**：支援開啟 `.brd` 和 `.aedb` 等 Ansys 佈局檔案。
- **簡易操作**：透過介面上的「Open File」按鈕即可輕鬆選取並載入檔案。

### 2. 圖層管理 (Layer Management)
- **圖層列表**：左側面板會自動列出檔案中的所有圖層。
- **可見性控制**：每個圖層皆有獨立的核取方塊 (Checkbox)，可隨時切換顯示或隱藏。
- **顏色自訂**：每個圖層名稱旁皆設有顏色選擇器 (Color Picker)，點擊即可自訂該圖層在畫布上的顯示顏色，並即時更新。

### 3. 互動式畫布 (Interactive Canvas)
- **幾何渲染**：使用 HTML5 Canvas 技術高效渲染佈局幾何圖形。
- **縮放 (Zoom)**：支援滑鼠滾輪縮放，可針對細節進行放大檢視。
- **平移 (Pan)**：支援滑鼠拖曳平移，方便瀏覽大型佈局。
- **自動適應**：載入檔案時，視圖會自動縮放至最佳大小以顯示完整設計。

### 4. 現代化介面 (Modern UI)
- **深色主題**：採用舒適的深色系介面設計，適合長時間使用。
- **響應式佈局**：介面元素會隨視窗大小自動調整。

## 系統需求 (Prerequisites)

在執行此程式之前，請確保您的系統滿足以下條件：

- **Python**: 建議使用 Python 3.11 或更高版本。
- **Ansys Electronics Desktop (AEDT)**: 由於後端依賴 `pyedb`，您需要安裝有效的 Ansys AEDT 軟體並擁有相應的授權。
- **uv**: 建議使用 `uv` 進行套件管理與執行 (可選，亦可使用標準 pip)。

## 安裝說明 (Installation)

1. **複製專案**
   將專案檔案下載至您的本地目錄。

2. **安裝依賴套件**
   使用 `uv` 或 `pip` 安裝所需的 Python 套件：
   ```bash
   # 使用 uv (推薦)
   uv sync

   # 或使用 pip
   pip install -r requirements.txt
   # 確保 pyproject.toml 中的依賴項已安裝: pywebview, pyaedt, pyedb
   ```

## 使用說明 (Usage)

1. **啟動應用程式**
   在終端機中執行 `main.py`：
   ```bash
   uv run main.py
   ```
   或
   ```bash
   python main.py
   ```

2. **操作步驟**
   - 程式啟動後，點擊上方選單的 **Open File** 按鈕。
   - 在彈出的檔案對話框中，選擇您的 `.brd` 或 `.aedb` 檔案。
   - 等待檔案載入，左側將顯示圖層列表，右側畫布將顯示佈局圖形。
   - 使用滑鼠滾輪縮放視圖，按住滑鼠左鍵拖曳移動視圖。
   - 點擊圖層旁的顏色方塊可更改顏色，取消勾選核取方塊可隱藏圖層。

## 專案結構 (Project Structure)

- `main.py`: 程式進入點，定義了 Python 後端 API 與 `pywebview` 的初始化邏輯。
- `model.py`: 負責與 Ansys EDB 進行交互，處理檔案讀取與幾何資料提取。
- `index.html`: 前端主頁面結構。
- `style.css`: 定義應用程式的樣式與深色主題。
- `script.js`: 前端邏輯，包含 Canvas 渲染、事件處理與前後端通訊。
- `pyproject.toml`: 專案設定檔與依賴項列表。
- `spec.md`: 技術規格文件。

## 技術細節 (Technical Details)

- **前端框架**: Vanilla HTML/CSS/JavaScript
- **後端框架**: Python (`pywebview`)
- **EDB 介面**: `pyedb` (Ansys)
- **通訊**: `pywebview` 提供的 JS-Python 橋接器

## 注意事項 (Notes)
- 本程式依賴 Ansys EDB，因此必須在安裝有 Ansys 軟體的環境下執行。
- 首次載入大型檔案可能需要一點時間進行幾何資料的提取與轉換。
